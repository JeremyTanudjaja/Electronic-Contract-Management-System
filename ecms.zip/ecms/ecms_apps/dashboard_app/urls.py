from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.index, name='dashboard_home'),

    # HTMX PATH
    # Update TCR
    path('update-tcr-value', views.update_tcr_value_htmx, name='update_tcr_value'),

    # show project value
    path('show-value-feature-dashboard', views.show_project_value_feature_htmx, name='show_value_feature'),
    path('show-value-region-dashboard', views.show_project_value_region_htmx, name='show_value_region'),
    path('update-value-feature-dashboard/', views.project_value_feature_htmx, name='update_value_feature_dashboard'),
    path('update-value-region-dashboard/', views.project_value_region_htmx, name='update_value_region_dashboard'),

    # show project count
    path('show-count-feature-dashboard', views.show_project_count_feature_htmx, name='show_count_feature'),
    path('show-count-region-dashboard', views.show_project_count_region_htmx, name='show_count_region'),
    path('update-count-feature-dashboard/', views.project_count_feature_htmx, name='update_count_feature_dashboard'),
    path('update-count-region-dashboard/', views.project_count_region_htmx, name='update_count_region_dashboard'),

    # show invoice count
    path('show-invoice-count-dashboard', views.show_invoice_count_htmx, name='show_invoice_count'),
    path('update-invoice-count-dashboard/', views.invoice_count_htmx, name='update_invoice_count')

]
