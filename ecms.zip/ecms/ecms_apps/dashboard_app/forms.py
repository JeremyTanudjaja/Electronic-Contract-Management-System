from django import forms


class ProjectFeatureDashboardFilterForm(forms.Form):
    start = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

    mobile_app = forms.BooleanField(required=False)
    web_app = forms.BooleanField(required=False)
    desktop_app = forms.BooleanField(required=False)
    cloud_service = forms.BooleanField(required=False)
    internet_of_things = forms.BooleanField(required=False)
    data_management_analytics = forms.BooleanField(required=False)
    blockchain = forms.BooleanField(required=False)
    artificial_intelligence = forms.BooleanField(required=False)
    datacenter = forms.BooleanField(required=False)
    disaster_recovery = forms.BooleanField(required=False)
    training = forms.BooleanField(required=False)


class ProjectRegionDashboardFilterForm(forms.Form):
    start = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

    Abu_Dhabi = forms.BooleanField(required=False)
    Dubai = forms.BooleanField(required=False)
    Sharjah = forms.BooleanField(required=False)
    Ajman = forms.BooleanField(required=False)
    Umm_Al_Quwain = forms.BooleanField(required=False)
    Fujairah = forms.BooleanField(required=False)
    Ras_Al_Khaimah = forms.BooleanField(required=False)


class InvoiceStatusFilterForm(forms.Form):
    start = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

