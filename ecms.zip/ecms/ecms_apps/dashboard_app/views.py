from django.db.models import Sum, Count, Value, CharField
from django.shortcuts import render
from ecms_apps.customer_app.models import CustomerInformation, CustomerContactInformation
from ecms_apps.project_app.models import ContractModel, ContractProgression
from ecms_apps.invoice_app.models import InvoiceModel, InvoiceModelDetail
import plotly.express as px
from django.db.models.functions import TruncMonth, Extract, Concat
from .forms import ProjectFeatureDashboardFilterForm, ProjectRegionDashboardFilterForm, InvoiceStatusFilterForm
import pandas as pd
from django.contrib.auth.decorators import login_required



# Create your views here.
@login_required
def show_project_value_feature_htmx(request):
    all_contract = ContractModel.objects.all()

    # Chart
    # Aggregating Data
    mobile_app = all_contract.filter(contract_feature_detail__mobile_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Mobile App')).order_by('month')
    web_app = all_contract.filter(contract_feature_detail__web_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Web App')).order_by('month')
    desktop_app = all_contract.filter(contract_feature_detail__desktop_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Desktop App')).order_by('month')
    cloud_service = all_contract.filter(contract_feature_detail__cloud_service=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Cloud Service')).order_by('month')
    internet_of_things = all_contract.filter(contract_feature_detail__internet_of_things=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('IoT')).order_by('month')
    data_management_analytics = all_contract.filter(contract_feature_detail__data_management_analytics=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('DMA')).order_by('month')
    blockchain = all_contract.filter(contract_feature_detail__blockchain=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Blockchain')).order_by('month')
    artificial_intelligence = all_contract.filter(contract_feature_detail__artificial_intelligence=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('AI')).order_by('month')
    datacenter = all_contract.filter(contract_feature_detail__datacenter=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Data Center')).order_by('month')
    disaster_recovery = all_contract.filter(contract_feature_detail__disaster_recovery=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Disaster Recovery')).order_by('month')
    training = all_contract.filter(contract_feature_detail__training=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Training')).order_by('month')

    data_list = [mobile_app, web_app, desktop_app, cloud_service, internet_of_things,
                 data_management_analytics, blockchain, artificial_intelligence, datacenter,
                 disaster_recovery, training]

    data_to_dataframe = []
    for data in data_list:
        for data_values in data:
            data_dict = {'month': data_values['month'], 'value': data_values['value'], 'label': data_values['label']}
            data_to_dataframe.append(data_dict)

    dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
    print(dataframe.head())

    fig = px.line(dataframe, x='month', y='value', color='label')

    fig.update_xaxes(
        dtick="M1",
        tickformat="%b\n%Y")

    chart = fig.to_html(include_plotlyjs="none")

    project_value_feature_form = ProjectFeatureDashboardFilterForm
    context_data = {'project_value_feature_form': project_value_feature_form,
                    'feature_chart': chart}
    return render(request, template_name='dashboard_page/dashboard_htmx/project_feature_htmx.html',
                  context=context_data)


@login_required
def show_project_value_region_htmx(request):
    all_contract = ContractModel.objects.all()

    # Chart
    # Aggregating Data
    abu_dhabi = all_contract.filter(requisition_by__company_region__iexact='ABU DHABI').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Abu Dhabi')).order_by('month')
    dubai = all_contract.filter(requisition_by__company_region__iexact='DUBAI').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Dubai')).order_by('month')
    sharjah = all_contract.filter(requisition_by__company_region__iexact='SHARJAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Sharjah')).order_by('month')
    ajman = all_contract.filter(requisition_by__company_region__iexact='AJMAN').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Ajman')).order_by('month')
    umm_al_quwain = all_contract.filter(requisition_by__company_region__iexact='UMM AL QUWAIN').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Umm Al Quwain')).order_by('month')
    fujairah = all_contract.filter(requisition_by__company_region__iexact='FUJAIRAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Fujairah')).order_by('month')
    ras_al_khaimah = all_contract.filter(requisition_by__company_region__iexact='RAS AL KHAIMAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
        label=Value('Ras Al Khaimah')).order_by('month')

    data_list = [abu_dhabi, dubai, sharjah, ajman, umm_al_quwain,
                 fujairah, ras_al_khaimah]

    data_to_dataframe = []
    for data in data_list:
        for data_values in data:
            data_dict = {'month': data_values['month'], 'value': data_values['value'], 'label': data_values['label']}
            data_to_dataframe.append(data_dict)

    dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
    print(dataframe.head())

    fig = px.bar(dataframe, x='month', y='value', color='label')

    fig.update_xaxes(
        dtick="M1",
        tickformat="%b\n%Y")

    chart = fig.to_html(include_plotlyjs="none")

    project_value_region_form = ProjectRegionDashboardFilterForm
    context_data = {'project_value_region_form': project_value_region_form,
                    'region_chart': chart}
    return render(request, template_name='dashboard_page/dashboard_htmx/project_client_region_htmx.html',
                  context=context_data)


@login_required
def project_value_feature_htmx(request):
    if request.htmx:
        data_list = []
        # print(request.POST)
        all_contract = ContractModel.objects.filter(created_time__gte=request.POST.get('start'),
                                                    created_time__lte=request.POST.get('end'))
        if request.POST.get('mobile_app'):
            mobile_app = all_contract.filter(contract_feature_detail__mobile_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Mobile App')).order_by('month')
            data_list.append(mobile_app)
        if request.POST.get('web_app'):
            web_app = all_contract.filter(contract_feature_detail__web_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Web App')).order_by('month')
            data_list.append(web_app)
        if request.POST.get('desktop_app'):
            desktop_app = all_contract.filter(contract_feature_detail__desktop_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Desktop App')).order_by('month')
            data_list.append(desktop_app)
        if request.POST.get('cloud_service'):
            cloud_service = all_contract.filter(contract_feature_detail__cloud_service=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Cloud Service')).order_by('month')
            data_list.append(cloud_service)
        if request.POST.get('internet_of_things'):
            internet_of_things = all_contract.filter(contract_feature_detail__internet_of_things=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('IoT')).order_by('month')
            data_list.append(internet_of_things)
        if request.POST.get('data_management_analytics'):
            data_management_analytics = all_contract.filter(
                contract_feature_detail__data_management_analytics=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('DMA')).order_by('month')
            data_list.append(data_management_analytics)
        if request.POST.get('blockchain'):
            blockchain = all_contract.filter(contract_feature_detail__blockchain=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Blockchain')).order_by('month')
            data_list.append(blockchain)
        if request.POST.get('artificial_intelligence'):
            artificial_intelligence = all_contract.filter(
                contract_feature_detail__artificial_intelligence=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('AI')).order_by('month')
            data_list.append(artificial_intelligence)
        if request.POST.get('datacenter'):
            datacenter = all_contract.filter(contract_feature_detail__datacenter=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Data Center')).order_by('month')
            data_list.append(datacenter)
        if request.POST.get('disaster_recovery'):
            disaster_recovery = all_contract.filter(contract_feature_detail__disaster_recovery=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Disaster Recovery')).order_by('month')
            data_list.append(disaster_recovery)
        if request.POST.get('training'):
            training = all_contract.filter(contract_feature_detail__training=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Training')).order_by('month')
            data_list.append(training)
        print(data_list)

        data_to_dataframe = []
        for data in data_list:
            for data_values in data:
                try:
                    data_dict = {'month': data_values['month'], 'value': data_values['value'],
                                 'label': data_values['label']}
                except KeyError:
                    # print('no key')
                    data_dict = {'month': None, 'value': None, 'label': None}
                finally:
                    data_to_dataframe.append(data_dict)

        dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
        # print(dataframe.head())

        fig = px.line(dataframe, x='month', y='value', color='label')

        fig.update_xaxes(
            dtick="M1",
            tickformat="%b\n%Y")

        chart = fig.to_html(include_plotlyjs="none")

        project_value_feature_form = ProjectFeatureDashboardFilterForm
        context_data = {'project_value_feature_form': project_value_feature_form,
                        'feature_chart': chart}

        return render(request, template_name='dashboard_page/dashboard_htmx/project_feature_htmx.html',
                      context=context_data)


@login_required
def project_value_region_htmx(request):
    if request.htmx:
        data_list = []
        # print(request.POST)
        all_contract = ContractModel.objects.filter(created_time__gte=request.POST.get('start'),
                                                    created_time__lte=request.POST.get('end'))
        if request.POST.get('Abu_Dhabi'):
            abu_dhabi = all_contract.filter(requisition_by__company_region__iexact='ABU DHABI').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Abu Dhabi')).order_by('month')
            data_list.append(abu_dhabi)
        if request.POST.get('Dubai'):
            dubai = all_contract.filter(requisition_by__company_region__iexact='DUBAI').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Dubai')).order_by('month')
            data_list.append(dubai)
        if request.POST.get('Sharjah'):
            sharjah = all_contract.filter(requisition_by__company_region__iexact='SHARJAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Sharjah')).order_by('month')
            data_list.append(sharjah)
        if request.POST.get('Ajman'):
            ajman = all_contract.filter(requisition_by__company_region__iexact='AJMAN').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Ajman')).order_by('month')
            data_list.append(ajman)
        if request.POST.get('Umm_Al_Quwain'):
            umm_al_quwain = all_contract.filter(requisition_by__company_region__iexact='UMM AL QUWAIN').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Umm Al Quwain')).order_by('month')
            data_list.append(umm_al_quwain)
        if request.POST.get('Fujairah'):
            fujairah = all_contract.filter(
                requisition_by__company_region__iexact='FUJAIRAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Fujairah')).order_by('month')
            data_list.append(fujairah)
        if request.POST.get('Ras_Al_Khaimah'):
            ras_al_khaimah = all_contract.filter(requisition_by__company_region__iexact='RAS AL KHAIMAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Sum('contract_value')).annotate(
                label=Value('Ras Al Khaimah')).order_by('month')
            data_list.append(ras_al_khaimah)

        print(data_list)

        data_to_dataframe = []
        for data in data_list:
            for data_values in data:
                try:
                    data_dict = {'month': data_values['month'], 'value': data_values['value'],
                                 'label': data_values['label']}
                except KeyError:
                    # print('no key')
                    data_dict = {'month': None, 'value': None, 'label': None}
                finally:
                    data_to_dataframe.append(data_dict)

        dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
        # print(dataframe.head())

        fig = px.bar(dataframe, x='month', y='value', color='label')

        fig.update_xaxes(
            dtick="M1",
            tickformat="%b\n%Y")

        chart = fig.to_html(include_plotlyjs="none")

        project_value_region_form = ProjectRegionDashboardFilterForm
        context_data = {'project_value_region_form': project_value_region_form,
                        'region_chart': chart}

        return render(request, template_name='dashboard_page/dashboard_htmx/project_client_region_htmx.html',
                      context=context_data)


def project_value(all_contract, active_contract, payment_term_contract):
    total_value = all_contract.aggregate(Sum('contract_value'))
    active_contract_value = active_contract.aggregate(Sum('contract_value'))
    payment_term_value = payment_term_contract.aggregate(Sum('contract_value'))

    project_value_data = {'total_value': total_value, 'active_contract_value': active_contract_value,
                          'payment_term_value': payment_term_value}
    return project_value_data


@login_required
def show_project_count_feature_htmx(request):
    all_contract = ContractModel.objects.all()

    # Chart
    # Aggregating Data
    mobile_app = all_contract.filter(contract_feature_detail__mobile_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Mobile App')).order_by('month')
    web_app = all_contract.filter(contract_feature_detail__web_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Web App')).order_by('month')
    desktop_app = all_contract.filter(contract_feature_detail__desktop_app=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Desktop App')).order_by('month')
    cloud_service = all_contract.filter(contract_feature_detail__cloud_service=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Cloud Service')).order_by('month')
    internet_of_things = all_contract.filter(contract_feature_detail__internet_of_things=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('IoT')).order_by('month')
    data_management_analytics = all_contract.filter(contract_feature_detail__data_management_analytics=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('DMA')).order_by('month')
    blockchain = all_contract.filter(contract_feature_detail__blockchain=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Blockchain')).order_by('month')
    artificial_intelligence = all_contract.filter(contract_feature_detail__artificial_intelligence=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('AI')).order_by('month')
    datacenter = all_contract.filter(contract_feature_detail__datacenter=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Data Center')).order_by('month')
    disaster_recovery = all_contract.filter(contract_feature_detail__disaster_recovery=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Disaster Recovery')).order_by('month')
    training = all_contract.filter(contract_feature_detail__training=True).annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Training')).order_by('month')

    data_list = [mobile_app, web_app, desktop_app, cloud_service, internet_of_things,
                 data_management_analytics, blockchain, artificial_intelligence, datacenter,
                 disaster_recovery, training]

    data_to_dataframe = []
    for data in data_list:
        for data_values in data:
            data_dict = {'month': data_values['month'], 'value': data_values['value'], 'label': data_values['label']}
            data_to_dataframe.append(data_dict)

    dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
    print(dataframe.head())

    fig = px.line(dataframe, x='month', y='value', color='label')

    fig.update_xaxes(
        dtick="M1",
        tickformat="%b\n%Y")
    fig.update_layout(yaxis_title="Project Count")

    chart = fig.to_html(include_plotlyjs="none")

    project_value_feature_form = ProjectFeatureDashboardFilterForm
    context_data = {'project_value_feature_form': project_value_feature_form,
                    'feature_chart': chart}
    return render(request, template_name='dashboard_page/dashboard_htmx/project_feature_count_htmx.html',
                  context=context_data)


@login_required
def show_project_count_region_htmx(request):
    all_contract = ContractModel.objects.all()

    # Chart
    # Aggregating Data
    abu_dhabi = all_contract.filter(requisition_by__company_region__iexact='ABU DHABI').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Abu Dhabi')).order_by('month')
    dubai = all_contract.filter(requisition_by__company_region__iexact='DUBAI').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Dubai')).order_by('month')
    sharjah = all_contract.filter(requisition_by__company_region__iexact='SHARJAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Sharjah')).order_by('month')
    ajman = all_contract.filter(requisition_by__company_region__iexact='AJMAN').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Ajman')).order_by('month')
    umm_al_quwain = all_contract.filter(requisition_by__company_region__iexact='UMM AL QUWAIN').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Umm Al Quwain')).order_by('month')
    fujairah = all_contract.filter(requisition_by__company_region__iexact='FUJAIRAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Fujairah')).order_by('month')
    ras_al_khaimah = all_contract.filter(requisition_by__company_region__iexact='RAS AL KHAIMAH').annotate(
        month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
        label=Value('Ras Al Khaimah')).order_by('month')

    data_list = [abu_dhabi, dubai, sharjah, ajman, umm_al_quwain,
                 fujairah, ras_al_khaimah]

    data_to_dataframe = []
    for data in data_list:
        for data_values in data:
            data_dict = {'month': data_values['month'], 'value': data_values['value'], 'label': data_values['label']}
            data_to_dataframe.append(data_dict)

    dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
    # print(dataframe.head())

    fig = px.bar(dataframe, x='month', y='value', color='label')

    fig.update_xaxes(
        dtick="M1",
        tickformat="%b\n%Y")
    fig.update_layout(yaxis_title="Project Count")

    chart = fig.to_html(include_plotlyjs="none")

    project_value_region_form = ProjectRegionDashboardFilterForm
    context_data = {'project_value_region_form': project_value_region_form,
                    'region_chart': chart}
    return render(request, template_name='dashboard_page/dashboard_htmx/project_client_region_count_htmx.html',
                  context=context_data)


@login_required
def project_count_feature_htmx(request):
    if request.htmx:
        data_list = []
        # print(request.POST)
        all_contract = ContractModel.objects.filter(created_time__gte=request.POST.get('start'),
                                                    created_time__lte=request.POST.get('end'))
        if request.POST.get('mobile_app'):
            mobile_app = all_contract.filter(contract_feature_detail__mobile_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Mobile App')).order_by('month')
            data_list.append(mobile_app)
        if request.POST.get('web_app'):
            web_app = all_contract.filter(contract_feature_detail__web_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Web App')).order_by('month')
            data_list.append(web_app)
        if request.POST.get('desktop_app'):
            desktop_app = all_contract.filter(contract_feature_detail__desktop_app=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Desktop App')).order_by('month')
            data_list.append(desktop_app)
        if request.POST.get('cloud_service'):
            cloud_service = all_contract.filter(contract_feature_detail__cloud_service=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Cloud Service')).order_by('month')
            data_list.append(cloud_service)
        if request.POST.get('internet_of_things'):
            internet_of_things = all_contract.filter(contract_feature_detail__internet_of_things=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('IoT')).order_by('month')
            data_list.append(internet_of_things)
        if request.POST.get('data_management_analytics'):
            data_management_analytics = all_contract.filter(
                contract_feature_detail__data_management_analytics=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('DMA')).order_by('month')
            data_list.append(data_management_analytics)
        if request.POST.get('blockchain'):
            blockchain = all_contract.filter(contract_feature_detail__blockchain=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Blockchain')).order_by('month')
            data_list.append(blockchain)
        if request.POST.get('artificial_intelligence'):
            artificial_intelligence = all_contract.filter(
                contract_feature_detail__artificial_intelligence=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('AI')).order_by('month')
            data_list.append(artificial_intelligence)
        if request.POST.get('datacenter'):
            datacenter = all_contract.filter(contract_feature_detail__datacenter=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Data Center')).order_by('month')
            data_list.append(datacenter)
        if request.POST.get('disaster_recovery'):
            disaster_recovery = all_contract.filter(contract_feature_detail__disaster_recovery=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Disaster Recovery')).order_by('month')
            data_list.append(disaster_recovery)
        if request.POST.get('training'):
            training = all_contract.filter(contract_feature_detail__training=True).annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Training')).order_by('month')
            data_list.append(training)
        print(data_list)

        data_to_dataframe = []
        for data in data_list:
            for data_values in data:
                try:
                    data_dict = {'month': data_values['month'], 'value': data_values['value'],
                                 'label': data_values['label']}
                except KeyError:
                    # print('no key')
                    data_dict = {'month': None, 'value': None, 'label': None}
                finally:
                    data_to_dataframe.append(data_dict)

        dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
        # print(dataframe.head())

        fig = px.line(dataframe, x='month', y='value', color='label')

        fig.update_xaxes(
            dtick="M1",
            tickformat="%b\n%Y")
        fig.update_layout(yaxis_title="Project Count")

        chart = fig.to_html(include_plotlyjs="none")

        project_value_feature_form = ProjectFeatureDashboardFilterForm
        context_data = {'project_value_feature_form': project_value_feature_form,
                        'feature_chart': chart}

        return render(request, template_name='dashboard_page/dashboard_htmx/project_feature_count_htmx.html',
                      context=context_data)


@login_required
def project_count_region_htmx(request):
    if request.htmx:
        data_list = []
        # print(request.POST)
        all_contract = ContractModel.objects.filter(created_time__gte=request.POST.get('start'),
                                                    created_time__lte=request.POST.get('end'))
        if request.POST.get('Abu_Dhabi'):
            abu_dhabi = all_contract.filter(requisition_by__company_region__iexact='ABU DHABI').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Abu Dhabi')).order_by('month')
            data_list.append(abu_dhabi)
        if request.POST.get('Dubai'):
            dubai = all_contract.filter(requisition_by__company_region__iexact='DUBAI').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Dubai')).order_by('month')
            data_list.append(dubai)
        if request.POST.get('Sharjah'):
            sharjah = all_contract.filter(requisition_by__company_region__iexact='SHARJAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Sharjah')).order_by('month')
            data_list.append(sharjah)
        if request.POST.get('Ajman'):
            ajman = all_contract.filter(requisition_by__company_region__iexact='AJMAN').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Ajman')).order_by('month')
            data_list.append(ajman)
        if request.POST.get('Umm_Al_Quwain'):
            umm_al_quwain = all_contract.filter(requisition_by__company_region__iexact='UMM AL QUWAIN').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Umm Al Quwain')).order_by('month')
            data_list.append(umm_al_quwain)
        if request.POST.get('Fujairah'):
            fujairah = all_contract.filter(
                requisition_by__company_region__iexact='FUJAIRAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Fujairah')).order_by('month')
            data_list.append(fujairah)
        if request.POST.get('Ras_Al_Khaimah'):
            ras_al_khaimah = all_contract.filter(requisition_by__company_region__iexact='RAS AL KHAIMAH').annotate(
                month=TruncMonth('created_time')).values('month').annotate(value=Count('contract_id')).annotate(
                label=Value('Ras Al Khaimah')).order_by('month')
            data_list.append(ras_al_khaimah)

        print(data_list)

        data_to_dataframe = []
        for data in data_list:
            for data_values in data:
                try:
                    data_dict = {'month': data_values['month'], 'value': data_values['value'],
                                 'label': data_values['label']}
                except KeyError:
                    # print('no key')
                    data_dict = {'month': None, 'value': None, 'label': None}
                finally:
                    data_to_dataframe.append(data_dict)

        dataframe = pd.DataFrame(data_to_dataframe, columns=['month', 'value', 'label'])
        # print(dataframe.head())

        fig = px.bar(dataframe, x='month', y='value', color='label')

        fig.update_xaxes(
            dtick="M1",
            tickformat="%b\n%Y")
        fig.update_layout(yaxis_title="Project Count")

        chart = fig.to_html(include_plotlyjs="none")

        project_value_region_form = ProjectRegionDashboardFilterForm
        context_data = {'project_value_region_form': project_value_region_form,
                        'region_chart': chart}

        return render(request, template_name='dashboard_page/dashboard_htmx/project_client_region_count_htmx.html',
                      context=context_data)


def project_count(all_contract, active_contract, payment_term_contract):
    total_contract_count = all_contract.aggregate(Count('contract_id'))
    active_contract_count = active_contract.aggregate(Count('contract_id'))
    payment_term_count = payment_term_contract.aggregate(Count('contract_id'))
    project_count_data = {'total_value': total_contract_count, 'active_contract_value': active_contract_count,
                          'payment_term_value': payment_term_count}
    return project_count_data


@login_required
def show_invoice_count_htmx(request):
    invoice_status = InvoiceModelDetail.objects.all().values('invoice_status').annotate(
        invoice_count=Count('invoice_id'))

    dataframe = pd.DataFrame.from_records(invoice_status)
    print(dataframe)

    fig = px.pie(data_frame=dataframe, values='invoice_count', names='invoice_status')
    chart = fig.to_html(include_plotlyjs="none")

    invoice_status_filter_form = InvoiceStatusFilterForm
    context_data = {'invoice_status_filter_form': invoice_status_filter_form,
                    'invoice_status_chart': chart}

    # print(invoice_status)
    return render(request, template_name='dashboard_page/dashboard_htmx/invoice_count_status.html',
                  context=context_data)


@login_required
def invoice_count_htmx(request):
    if request.htmx:
        invoice_status = (InvoiceModelDetail.objects.filter(due_date__gte=request.POST.get('start'),
                                                            due_date__lte=request.POST.get('end')).
                          values('invoice_status').annotate(invoice_count=Count('invoice_id')))

        dataframe = pd.DataFrame.from_records(invoice_status)
        print(dataframe)

        if(len(dataframe)) <= 0:
            chart = '<h1 style="text-align:center;">No Data</h1>'
        else:
            fig = px.pie(data_frame=dataframe, values='invoice_count', names='invoice_status')
            chart = fig.to_html(include_plotlyjs="none")

        invoice_status_filter_form = InvoiceStatusFilterForm
        context_data = {'invoice_status_filter_form': invoice_status_filter_form,
                        'invoice_status_chart': chart}

        # print(invoice_status)
        return render(request, template_name='dashboard_page/dashboard_htmx/invoice_count_status.html',
                      context=context_data)


def invoice_count():
    invoice = InvoiceModelDetail.objects.all()
    total_invoice_value = invoice.aggregate(Sum('payment_after_tax'))
    sent_invoice_value = invoice.filter(invoice_status__iexact='SENT').aggregate(
        Sum('payment_after_tax'))
    stored_invoice_value = invoice.filter(invoice_status__iexact='STORED').aggregate(
        Sum('payment_after_tax'))
    pending_invoice_value = invoice.filter(invoice_status__iexact='PENDING').aggregate(
        Sum('payment_after_tax'))
    missing_invoice_value = invoice.filter(invoice_status__iexact='MISSING').aggregate(
        Sum('payment_after_tax'))
    data_dict = {'total_invoice_value': total_invoice_value, 'sent_invoice_value': sent_invoice_value,
                 'stored_invoice_value': stored_invoice_value, 'pending_invoice_value': pending_invoice_value,
                 'missing_invoice_value': missing_invoice_value}
    return data_dict


@login_required
def index(request):
    all_contract = ContractModel.objects.all()
    active_contract = ContractModel.objects.filter(is_active=True)
    payment_term_contract = ContractModel.objects.filter(contract_stage__gt=6)

    project_value_stats = project_value(all_contract=all_contract, active_contract=active_contract,
                                        payment_term_contract=payment_term_contract)
    project_count_stats = project_count(all_contract=all_contract, active_contract=active_contract,
                                        payment_term_contract=payment_term_contract)
    invoice_stats = invoice_count()

    current_tcr = active_contract.order_by("-created_time")[:10]

    # print(project_count_chart)
    context_data = {'project_value': project_value_stats,
                    'project_count': project_count_stats,
                    'invoice_value': invoice_stats,
                    'current_tcr': current_tcr}
    # print(context_data)
    return render(request, template_name='dashboard_page/dashboard_home_page.html', context=context_data)


@login_required
def update_tcr_value_htmx(request):
    if request.htmx:
        current_tcr = ContractModel.objects.filter(is_active=True,
                                                   created_time__gte=request.POST.get('start_date'),
                                                   created_time__lte=request.POST.get('end_date'))
        current_tcr = current_tcr.order_by("-created_time")
        context_data = {'current_tcr': current_tcr}
        return render(request, template_name='dashboard_page/dashboard_htmx/update_tcr_htmx.html', context=context_data)
