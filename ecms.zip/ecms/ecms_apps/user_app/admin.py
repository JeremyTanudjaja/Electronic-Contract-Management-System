from django.contrib import admin
from .models import ECMS_User, Commercial, Sales, Admin, ProductContact
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django import forms
from django.core.exceptions import ValidationError

class UserCreationForm(forms.ModelForm):

    password1 = forms.CharField(label="Password", widget=forms.PasswordInput)
    password2 = forms.CharField(
        label="Password confirmation", widget=forms.PasswordInput
    )

    class Meta:
        model = ECMS_User
        fields = ['username', 'role']


    def save(self, commit=True):
        # Save the provided password in hashed format
        user = super().save(commit=False)

        # check if password 1 and password 2 is the same or not
        password1 = self.cleaned_data.get("password1")
        password2 = self.cleaned_data.get("password2")

        # if it's not the same then raise validation error
        if password1 and password2 and password1 != password2:
            raise forms.ValidationError("Passwords don't match")

        # if it is the same then hash the password using the value of password1
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class UserAdmin(BaseUserAdmin):

    # form info that will be generated when we create a new User
    add_form = UserCreationForm

    # fields that will be shown in the User Admin List Page
    list_filter = ['role', 'is_active', 'groups', 'is_superuser']
    list_display = ['username']

    # fields that will be shown in the User Admin Detail Page
    fieldsets = (
        ('Personal Info', {'fields':
                               ('honorific', 'first_name', 'last_name', 'email',
                                'username', 'password', 'role','telephone', 'slug','last_active_time', 'created_time')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
    )

    # field that is generated when a new user wants to be created,
    # needs to be connected to a UserCreationForm Class (up there)
    add_fieldsets = [
        (
            None,
            {
                "classes": ["wide"],
                "fields": ["username", "role", "password1", "password2"],
            },
        ),
    ]


# Register your models here.
admin.site.register(ECMS_User, UserAdmin)
admin.site.register(Sales)
admin.site.register(Commercial)
admin.site.register(Admin)
admin.site.register(ProductContact)
