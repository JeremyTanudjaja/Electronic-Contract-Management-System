from django import forms
from django.contrib.auth import authenticate

from .models import ECMS_User
from django.core.exceptions import ObjectDoesNotExist, ValidationError
from django.contrib.auth.forms import AuthenticationForm


class AuthForm(AuthenticationForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget = forms.widgets.TextInput(attrs={
            'placeholder': 'username', 'required': 'true'
        })
        self.fields['password'].widget = forms.widgets.PasswordInput(attrs={
            'placeholder': 'password', 'required': 'true'
        })

    def clean(self):
        # get the data from the form
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        print(f"Auth Form: {username} | {password}")

        # if username and password is detected
        if username and password:
            # authenticate the user
            self.user_cache = authenticate(username=username, password=password)

            # if authentication fail i.e. no user found, raise Validation Error
            if self.user_cache is None:
                raise ValidationError("Please enter a correct username and password. "
                                      "Note that both fields are case-sensitive. Make"
                                      "sure you've already activated your account")
            # This does not work, if the user is inactive, it will automatically return
            # None on the authenticate method
            try:
                if not self.user_cache.is_active:
                    raise ValidationError("User is not active, Please active your account first")
            except AttributeError:
                raise ValidationError("User is not active, Please active your account first")

        return self.cleaned_data


class ActivateRegistration(forms.Form):
    # Create the form that we need to use to be able to use the FormView
    username = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Enter Your Username'}
    ))
    password = forms.CharField(required=True, widget=forms.PasswordInput(
        attrs={"placeholder": 'Enter Your Given Password'}
    ))
    first_name = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Enter Your First Name'}
    ))
    last_name = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Enter Your Last Name'}
    ))
    email = forms.EmailField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Enter Your Email'}
    ))
    telephone = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Enter Your Telephone'}
    ))
    new_password = forms.CharField(required=True, widget=forms.PasswordInput(
        attrs={"placeholder": 'Enter Your New Password'}
    ))
    confirm_password = forms.CharField(required=True, widget=forms.PasswordInput(
        attrs={"placeholder": 'Confirm Password'}
    ))

    # Field that enables us to use multiple choice field
    honorific = forms.ChoiceField(required=True, widget=forms.Select(
        attrs={"class": 'minimal', 'id': 'honorific'}),
                                  choices=[('Mr.', 'Mr.'), ('Ms.', 'Ms.')]
                                  )

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('new_password')
        password2 = cleaned_data.get('confirm_password')

        # Check if user is in db
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        try:
            user = ECMS_User.objects.get(username=username)
        except ObjectDoesNotExist:
            user = False

        if user:
            # check if password is correct
            if user.check_password(password):
                print('form password check complete, user and password match')
                # check if user is already active, if active, then deny activate access
                # to change profile data, user need to use the profile button once they logged in
                if user.is_active == True:
                    # we use ValidationError from django.exceptions since it is not a field error
                    raise ValidationError("User is already active, to change user data "
                                          "please use the profile button after you've logged in")
            else:
                raise forms.ValidationError({"password": "Old Password is Wrong"})
        else:
            raise forms.ValidationError({"username": "User not detected in Database"})

        # check if the password confirmation is correct
        if password1 != password2:
            raise forms.ValidationError({"confirm_password": "Password mismatch error "
                                                             "Make sure New Password and "
                                                             "Confirmed Password match"})

class UserUpdateForm(forms.ModelForm):

    class Meta:
        model = ECMS_User
        exclude = ['username', 'role', 'slug', 'last_active_time', 'created_time', 'is_active',
                   'password', 'date_joined', 'groups', 'user_permissions', 'is_staff', 'last_login',
                   'is_superuser']

    new_password = forms.CharField(required=False, widget=forms.PasswordInput(
        attrs={"placeholder": 'Enter Your New Password'}
    ))

    confirm_password = forms.CharField(required=False, widget=forms.PasswordInput(
        attrs={"placeholder": 'Confirm Password'}
    ))

    def clean(self):
        cleaned_data = super().clean()
        print(cleaned_data)
        if cleaned_data.get('new_password') and cleaned_data.get('confirm_password'):
            print('new password detected in form clean')
            password1 = cleaned_data.get('new_password')
            password2 = cleaned_data.get('confirm_password')
            if password1 != password2:
                raise forms.ValidationError({"confirm_password": "Password mismatch error "
                                                                 "Make sure New Password and "
                                                                 "Confirmed Password match"})
        return cleaned_data
