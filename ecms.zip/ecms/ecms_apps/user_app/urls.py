from django.urls import path
from . import views

app_name = 'user'

urlpatterns = [
    path('login/', views.OpeningView.as_view(), name='login'),
    path('activate/', views.RegistrationActivateView.as_view(), name='activate'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('profile/', views.UserProfileView.as_view(), name='user_profile'),
    path('update_profile', views.UserUpdateView.as_view(), name='user_update')
]
