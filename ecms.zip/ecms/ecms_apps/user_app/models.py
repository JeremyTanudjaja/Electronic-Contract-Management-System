from django.contrib.auth.models import AbstractUser, PermissionsMixin
from django.db import models
from datetime import datetime
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import Group
from django.utils.crypto import get_random_string


# Create your models here.
class ECMS_User(AbstractUser, PermissionsMixin):
    class Role(models.TextChoices):
        ADMIN = "ADMIN", 'Admin'
        SALES = "SALES", 'Sales'
        COMMERCIAL = "COMMERCIAL", 'Commercial'
        PRODUCT = "PRODUCT", "Product"
        UNDEFINED = 'UNDEFINED', 'Undefined'

    class Honorific(models.TextChoices):
        MISTER = "Mr.", 'Mr.'
        MISS = 'Ms.', 'Ms.'
        UNDEFINED = 'UNDEFINED', 'Undefined'

    # ID field and other stuff
    staff_id = models.BigAutoField(primary_key=True)
    honorific = models.CharField(verbose_name='Honorific', max_length=255, choices=Honorific.choices, null=False,
                                 default=Honorific.UNDEFINED)

    # No Need To Define, as it is already in the Base Django User
    # first_name = models.CharField(max_length=255)
    # last_name = models.CharField(max_length=255)
    # username = models.TextField(max_length=255, unique=True, null=False)
    # password = models.TextField(max_length=255)
    # email = models.EmailField(max_length=255)
    # is_active = models.BooleanField()
    # group is used for Permission, The Default Django Group is already sophisticated enough for it

    telephone = models.CharField(verbose_name='Telephone Number', max_length=25)

    created_time = models.DateTimeField(verbose_name='User Creation Time', null=False, default=datetime.now)
    last_active_time = models.DateTimeField(verbose_name='Last User Activity', null=True, default=datetime.now)

    role = models.CharField(max_length=255, choices=Role.choices, null=False, default=Role.UNDEFINED)
    slug = models.SlugField(max_length=50, unique=True)

    def save(self, *args, **kwargs):
        # if it is a new entry then create a new slug,
        # we assumed all data already have a slug
        if not self.staff_id or not self.slug:
            slug_text = str(self.role) + '-' + get_random_string(8, 'ABCDEFG12345678abcdefg') + '-' + str(self.username)
            self.slug = slug_text
            if self.role == 'ADMIN' or self.role == 'UNDEFINED':
                self.is_active = True
            else:
                self.is_active = False
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.username


@receiver(post_save, sender=ECMS_User)
def create_user_department(sender, instance, created, **kwargs):
    if created:
        if instance.role == 'ADMIN':
            admin_object = Admin(admin_staff_id=instance, department='Contract Management Team')
            admin_object.save()
            instance.groups.add(Group.objects.get(name='Admin'))
        elif instance.role == 'SALES':
            sales_object = Sales(sales_staff_id=instance, projects_assigned=0, total_project_assigned=0)
            sales_object.save()
            instance.groups.add(Group.objects.get(name='Sales'))
        elif instance.role == 'COMMERCIAL':
            commercial_object = Commercial(commercial_staff_id=instance, projects_assigned=0,
                                           total_project_assigned=0)
            commercial_object.save()
            instance.groups.add(Group.objects.get(name='Commercial'))
        elif instance.role == 'PRODUCT':
            product_object = ProductContact(product_team_id=instance, projects_assigned=0,
                                            total_project_assigned=0)
            product_object.save()
            instance.groups.add(Group.objects.get(name='Product'))


class Commercial(models.Model):
    commercial_staff_id = models.OneToOneField('user_app.ECMS_User', on_delete=models.RESTRICT,
                                               related_name='commercial_staff')

    # projects assigned is needed to auto give a project to commercial staff that has the least
    # project
    projects_assigned = models.IntegerField(verbose_name='Project Currently Assigned')
    total_project_assigned = models.IntegerField(verbose_name='Total Project in Company')

    def __str__(self):
        return f"{self.commercial_staff_id.first_name} {self.commercial_staff_id.last_name}"


class Sales(models.Model):
    sales_staff_id = models.OneToOneField('user_app.ECMS_User', on_delete=models.RESTRICT, related_name='sales_staff')

    # Just to give info about the total project that a sales has
    projects_assigned = models.IntegerField(verbose_name='Project Currently Assigned')
    total_project_assigned = models.IntegerField(verbose_name='Total Project in Company')

    def __str__(self):
        return f"{self.sales_staff_id.first_name} {self.sales_staff_id.last_name}"


class ProductContact(models.Model):
    product_team_id = models.OneToOneField('user_app.ECMS_User', on_delete=models.RESTRICT,
                                           related_name='product_staff')

    # Just to give info about the total project that a product team has
    projects_assigned = models.IntegerField(verbose_name='Project Currently Assigned')
    total_project_assigned = models.IntegerField(verbose_name='Total Project in Company')

    def __str__(self):
        return f"{self.product_team_id.first_name} {self.product_team_id.last_name}"


class Admin(models.Model):
    admin_staff_id = models.OneToOneField('user_app.ECMS_User', on_delete=models.RESTRICT, related_name='admin_staff')
    department = models.CharField(max_length=255, null=False, default='Contract Management Team')

    def __str__(self):
        return f"{self.admin_staff_id.first_name} {self.admin_staff_id.last_name}"
