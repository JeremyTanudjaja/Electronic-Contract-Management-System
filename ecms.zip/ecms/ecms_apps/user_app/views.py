from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import TemplateView, FormView
from django.contrib.auth.views import LoginView, LogoutView
from .forms import ActivateRegistration, AuthForm, UserUpdateForm
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import ECMS_User
from django.contrib.auth.hashers import make_password


# Create your views here.
class OpeningView(LoginView):
    template_name = 'registration/login.html'
    authentication_form = AuthForm


class CustomLogoutView(LoginRequiredMixin, LogoutView):
    pass


class UserProfileView(LoginRequiredMixin, TemplateView):
    template_name = 'user_page/user_profile.html'


class UserUpdateView(LoginRequiredMixin, FormView):
    template_name = 'user_page/user_profile_update.html'
    success_url = reverse_lazy('user:user_profile')
    form_class = UserUpdateForm

    def get_form(self, form_class=form_class):
        return form_class(instance=self.request.user, **self.get_form_kwargs())

    def form_valid(self, form):
        print('form valid')
        print(form.instance)
        if form.cleaned_data['new_password']:
            print('New Password is detected?')
            form.instance.password = make_password(form.cleaned_data['new_password'])
        form.save()
        return super().form_valid(form)

    def form_invalid(self, form):
        print(form.errors)
        return super().form_invalid(form)


class RegistrationActivateView(FormView):
    # base template that will be shown when we go to the page
    template_name = 'registration/registration.html'

    # the form that we are going to use, we can't use html generated form
    # because FormView requires a form_class, without it, it will not work
    form_class = ActivateRegistration

    # if the submit action is successful, redirect to this page
    success_url = '/user/login/'

    # if form is valid, i.e, all the form data is filled and there are no errors
    # do this
    def form_valid(self, form):
        # grab the username and password that the user inputted
        # this credential will be used to check if the update operation
        # will be done or not
        username = form.cleaned_data['username']
        old_pass = form.cleaned_data['password']

        # grab the user data
        user = ECMS_User.objects.get(username=username)
        print(user)

        # call a function that we define to check the password
        # it will return True if the password is correct
        if self.check_user_password(user, old_pass):
            print('nice')
            # do the update, parse the user object and the data from our form
            self.update_user(form, user)
        return super().form_valid(form)

    # Check whether the password is the same as password stored in the database
    def check_user_password(self, user: ECMS_User, password: str):
        # use the built-in check_password method from BaseUser since it is hashed.
        # we can't compare it using normal comparation operator
        if user.check_password(password):
            print('Password is The Same')
            return True
        else:
            print('Password is not the same')
            return False

    def update_user(self, form: ActivateRegistration, user: ECMS_User):
        # grabs all the data form the form and add it to the user object
        user.first_name = form.cleaned_data['first_name']
        user.last_name = form.cleaned_data['last_name']
        user.email = form.cleaned_data['email']
        user.telephone = form.cleaned_data['telephone']
        user.honorific = form.cleaned_data['honorific']
        user.set_password(form.cleaned_data['new_password'])
        user.is_active = True

        # save the new data to the user object
        user.save()

    def form_invalid(self, form):
        # if form is invalid, i.e. there are fields that are not filled or something else
        # then print invalid form
        print(form.errors)
        print('invalid form')
        return super().form_invalid(form)
