from .models import CustomerInformation, CustomerContactInformation
from django import forms


class CreateNewCustomerForm(forms.ModelForm):
    class Meta:
        model = CustomerInformation
        exclude = ('company_slug', 'created_by', 'last_updated_by', 'company_created_time')

    company_name = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Customer Name'}
    ))
    company_email = forms.EmailField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Customer Email'}
    ))
    company_telephone = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Customer Telephone'}
    ))
    company_address = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": "Customer's Headquarter Address"}
    ))
    company_city = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": "Customer's Headquarter City"}
    ))

    company_country = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": "United Arab Emirates"}
    ))
    company_description = forms.CharField(required=True, widget=forms.Textarea(
        attrs={"placeholder": "Customer Description, for example: XYZ LLC is a Company that mainly produces ..."}
    ))


class CreateNewContactForm(forms.ModelForm):
    class Meta:
        model = CustomerContactInformation
        exclude = ('contact_active', 'contact_slug', 'created_by', 'last_updated', 'company_id','created_time')

    contact_first_name = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'First Name'}
    ))
    contact_last_name = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Last Name'}
    ))
    contact_email = forms.EmailField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Contact Email'}
    ))
    contact_telephone = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Contact Telephone'}
    ))

