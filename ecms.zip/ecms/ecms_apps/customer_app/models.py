from django.db import models
from django.utils.crypto import get_random_string
from datetime import datetime

# Create your models here.
class CustomerInformation(models.Model):
    class RegionType(models.TextChoices):
        ABU_DHABI = 'ABU DHABI', 'Abu Dhabi'
        DUBAI = 'DUBAI', 'Dubai'
        SHARJAH = 'SHARJAH', 'Sharjah'
        AJMAN = 'AJMAN', 'Ajman'
        UMM_AL_QUWAIN = 'UMM AL QUWAIN', 'Umm Al Quwain'
        FUJAIRAH = 'FUJAIRAH', 'Fujairah'
        RAS_AL_KHAIMAH = 'RAS AL KHAIMAH', 'Ras Al Khaimah'




    company_id = models.BigAutoField(primary_key=True)
    company_name = models.CharField(max_length=255, null=False)
    company_email = models.EmailField(max_length=255)
    company_telephone = models.CharField(max_length=255, null=False)
    company_slug = models.SlugField(max_length=255, null=True)
    company_address = models.CharField(max_length=255, null=False)
    company_city = models.CharField(max_length=255, null=False)
    company_region = models.CharField(max_length=255, null=False, choices=RegionType.choices)
    company_country = models.CharField(max_length=255)
    company_description = models.TextField()
    created_by = models.ForeignKey('user_app.ECMS_User', null=True, on_delete=models.RESTRICT,
                                   related_name='user_creator')
    last_updated_by = models.ForeignKey('user_app.ECMS_User', null=True, on_delete=models.RESTRICT,
                                        related_name='user_updator')
    company_created_time = models.DateTimeField(verbose_name='Created Time', null=True, default=datetime.now)

    class Meta:
        verbose_name = 'Customer Information'
        verbose_name_plural = 'Customer Information'

    def __str__(self):
        return f"{self.company_name}-{self.company_city}"

    def save(self, *args, **kwargs):
        # Create an Automatic Slug for new company data or if the company does not have slug yet
        if not self.company_id or not self.company_slug:
            slug_text = str(self.company_name) + '-' + get_random_string(8, 'ABCDEFG12345678abcdefg')
            self.company_slug = slug_text
        return super().save(*args, **kwargs)


class CustomerContactInformation(models.Model):
    customer_contact_id = models.BigAutoField(primary_key=True)
    contact_first_name = models.CharField(max_length=255)
    contact_last_name = models.CharField(max_length=255)
    contact_email = models.EmailField(max_length=255)
    contact_telephone = models.CharField(max_length=255)
    contact_active = models.BooleanField(default=True)
    contact_slug = models.SlugField(max_length=255, null=True)
    created_by = models.ForeignKey('user_app.ECMS_User', null=True, on_delete=models.RESTRICT,
                                  related_name='contact_creator')
    last_updated = models.ForeignKey('user_app.ECMS_User', null=True, on_delete=models.RESTRICT,
                                    related_name='contact_updator')
    company_id = models.ForeignKey('customer_app.CustomerInformation', related_name='company_contact_info',
                                   on_delete=models.RESTRICT)
    created_time = models.DateTimeField(verbose_name='Created Time', null=True, default=datetime.now)

    def __str__(self):
        return f"{self.company_id}-{self.contact_first_name} {self.contact_last_name}"

    def save(self, *args, **kwargs):
        # Create an Automatic Slug for new company contact data or if the company contact does not have slug yet
        if not self.customer_contact_id or not self.contact_slug:
            slug_text = (str(self.company_id) + '-' + get_random_string(8, 'ABCDEFG12345678abcdefg')
                         + '-' + str(self.contact_first_name) + ' ' + str(self.contact_last_name))
            self.contact_slug = slug_text
        return super().save(*args, **kwargs)
