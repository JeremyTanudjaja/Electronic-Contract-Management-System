from django.urls import path
from . import views

app_name = 'customer'

urlpatterns = [
    path('customer_list/', views.CustomerListView.as_view(), name='customer_list'),
    path('customer_list/<str:param>/', views.CustomerListView.as_view(), name='customer_list'),
    path('customer_add/', views.CustomerAddView.as_view(), name='customer_add'),
    path('customer_detail/<slug>', views.CustomerDetailView.as_view(), name='customer_detail'),
    path('customer_edit/<slug>', views.CustomerEditView.as_view(), name='customer_edit'),
    path('customer_contact_detail/<slug>', views.ContactDetailView.as_view(), name='customer_contact'),
    path('customer_contact_update/<slug>', views.ContactEditView.as_view(), name='contact_update'),
    path('customer_contact_create/<slug>', views.ContactAddView.as_view(), name='contact_create'),
]
