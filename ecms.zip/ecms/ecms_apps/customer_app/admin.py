from django.contrib import admin
from .models import CustomerInformation, CustomerContactInformation
from django import forms


class CustomerAdmin(admin.ModelAdmin):
    readonly_fields = ['company_slug']


class ContactCreationForm(forms.ModelForm):
    class Meta:
        model = CustomerContactInformation
        fields = ['contact_first_name', 'contact_last_name', 'contact_email',
                  'contact_telephone', 'company_id']


class CustomerContactAdmin(admin.ModelAdmin):
    form = ContactCreationForm
    readonly_fields = ['contact_slug']
    fieldsets = (
        ('Contact Info', {'fields':
                              ('contact_first_name', 'contact_last_name', 'contact_email',
                               'contact_telephone', 'contact_slug', 'company_id', 'contact_active',
                               'created_by', 'last_updated', 'created_time')}),
    )

    add_fieldsets = [
        (
            None,
            {
                "classes": ["wide"],
                "fields": ['contact_first_name', 'contact_last_name', 'contact_email',
                           'contact_telephone', 'company_id', 'created_by', 'last_updated'],
            },
        ),
    ]


# Register your models here.
admin.site.register(CustomerInformation, CustomerAdmin)
admin.site.register(CustomerContactInformation, CustomerContactAdmin)
