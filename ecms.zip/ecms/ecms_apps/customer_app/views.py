from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, CreateView, DetailView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from .models import CustomerInformation, CustomerContactInformation
from .forms import CreateNewCustomerForm, CreateNewContactForm
from django.db.models.query import QuerySet
from django.db.models import Sum, Count


# Create your views here.
class CustomerListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    template_name = 'customer_page/customer_list.html'
    model = CustomerInformation
    paginate_by = 4
    permission_required = ['customer_app.view_customerinformation']

    def search(self, query_set: QuerySet):
        # This function will be run to check whether there is a search request from
        # GET. If there is, then filter the query_set that was defined in the get_query_set method
        # Filter by the company name. i__contains is the comparison operator (a combination of lower()
        # and comparison)
        if self.request.GET.get('search'):
            search = self.request.GET.get('search')
            print('exist')
            query_set = query_set.filter(company_name__icontains=search)
            return query_set
        else:
            return query_set

    def sort_by(self, query_set: QuerySet, *args, **kwargs):
        # Since there are two urls that goes into this ListView. One is the
        # basic url without the sorting parameter and the other is with one
        # this function is created to sort the query_set if we have a parameter
        # in the url. it will check if there is the parameter in the url via the
        # kwargs, then it will sort it based on the parameter.
        if self.kwargs.get('param'):
            parameter = self.kwargs.get('param')
            if parameter == 'company_city':
                query_set = query_set.order_by('company_city')
            elif parameter == 'oldest':
                query_set = query_set.order_by('-company_created_time')
            elif parameter == 'newest':
                query_set = query_set.order_by('company_created_time')
            return query_set
        else:
            return query_set

    def get_queryset(self, *args, **kwargs):
        # When we call a view, this is the very first function that is instantiated
        # basically it grabs the query_set i.e. the model query from the model that
        # we have defined as an attribute via the super() call. then we can modify it
        # in this method. For this ListView, i modify it if there is a sorting parameter
        # or a search parameter
        query_set = super().get_queryset()
        query_set = self.sort_by(query_set=query_set)
        # Search Function
        query_set = self.search(query_set=query_set)
        return query_set


class CustomerAddView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    # Specify The model that we are using
    model = CustomerInformation

    # Templates and redirect url
    template_name = 'customer_page/customer_add.html'
    success_url = '/customer/customer_list/'

    # Specify the form that we want to use
    form_class = CreateNewCustomerForm

    permission_required = ['customer_app.view_customerinformation',
                           'customer_app.add_customerinformation']

    def form_valid(self, form):
        form.instance.created_by = self.request.user
        form.instance.last_updated_by = self.request.user
        return super().form_valid(form)

    def form_invalid(self, form):
        print('form invalid')
        return super().form_invalid(form)


class CustomerEditView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = CustomerInformation
    slug_field = 'company_slug'
    fields = ['company_name', 'company_email', 'company_telephone',
              'company_address', 'company_city', 'company_region',
              'company_country', 'company_description']
    template_name = 'customer_page/customer_edit.html'
    context_object_name = 'this_customer'
    permission_required = ['customer_app.view_customerinformation',
                           'customer_app.change_customerinformation']

    def get_success_url(self):
        return reverse_lazy('customer:customer_list')

    def form_valid(self, form):
        form.instance.last_updated_by = self.request.user
        return super().form_valid(form)


# This view is used to server the customer detail page when you click
# on one of the detail button in the customer list page
class CustomerDetailView(LoginRequiredMixin, PermissionRequiredMixin,DetailView):
    template_name = 'customer_page/customer_detail.html'
    model = CustomerInformation
    context_object_name = 'this_customer_detail'

    permission_required = ['customer_app.view_customerinformation',
                           'customer_app.change_customerinformation']

    # slug_url_kwarg to specify the slug argument that we are going to get
    # from the url and template
    # slug_url_kwarg = 'slug'

    # We need to specifiy the slug field attribute based on our defined
    # slug field in the model. If not, the DetailView will try to find
    # a field named `slug` and if it is not there, it will return an error
    slug_field = 'company_slug'

    # redefine the queryset to get the result based on the company_slug
    # def get_queryset(self):
    #     # print(self.kwargs['slug'])
    #     a = self.kwargs['slug']
    #     return CustomerInformation.objects.filter(company_slug=a)

    # We can also define it as such, grab the super which is our model
    # and just filter it
    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(company_slug__iexact=self.kwargs.get('slug'))

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        project_list = context['this_customer_detail'].client_requisition.all()

        # Details that we want for the customer summary
        context['active_project'] = project_list.filter(is_active=True)
        context['related_project'] = project_list
        context['total_project_sum'] = project_list.aggregate(Sum('contract_value'))
        context['finished_project'] = project_list.filter(contract_stage__gt=6)

        return context


# This View is for the Contact Detail View. It basically serves
# to show the contact information when you click on the contact detail
# from the customer detail page
class ContactDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    template_name = 'customer_page/customer_contact.html'
    model = CustomerContactInformation
    context_object_name = 'this_customer_contact'
    slug_field = 'contact_slug'

    permission_required = ['customer_app.view_customercontactinformation']

    def get_queryset(self):
        queryset = super().get_queryset()
        return queryset.filter(contact_slug__iexact=self.kwargs.get('slug'))


class ContactAddView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = CustomerContactInformation
    template_name = 'customer_page/customer_contact_add.html'
    form_class = CreateNewContactForm

    permission_required = ['customer_app.view_customercontactinformation',
                           'customer_app.add_customercontactinformation']

    def form_valid(self, form, *args, **kwargs):
        # we parse in the slug from our html page when we click
        # the submit button so that we could automatically
        # create the company relationship. The slug inside the html page
        # was put there via the get_context_data. The get_context data will
        # grab our slug when we first go into this page
        form.instance.created_by = self.request.user
        form.instance.last_updated = self.request.user
        company_slug = self.kwargs['slug']
        form.instance.company_id = CustomerInformation.objects.get(company_slug=company_slug)
        return super().form_valid(form)

    def get_success_url(self):
        # we have parsed the slug via the get_context_data, to the page. When
        # the user click submit, get the slug that is in the page and input it
        # into the form as a kwargs. From there we can access the slug again
        # to redirect
        customer_slug = self.kwargs['slug']
        return reverse_lazy('customer:customer_detail', kwargs={'slug': customer_slug})

    def get_context_data(self, *args, **kwargs):
        context = super(ContactAddView, self).get_context_data(**kwargs)
        # get the customer/company slug, this is needed so that we could print the slug
        # in our page and use it for the form and back button
        context['slug'] = self.kwargs['slug']
        return context


class ContactEditView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = CustomerContactInformation
    slug_field = 'contact_slug'
    fields = ['contact_first_name', 'contact_last_name', 'contact_email',
              'contact_telephone', 'contact_active']
    template_name = 'customer_page/customer_contact_edit.html'
    context_object_name = 'this_customer_contact'

    permission_required = ['customer_app.view_customercontactinformation',
                           'customer_app.change_customercontactinformation']

    def get_success_url(self):
        contact_slug = self.kwargs['slug']
        return reverse_lazy('customer:customer_contact', kwargs={'slug': contact_slug})

    def form_valid(self, form):
        form.instance.last_updated = self.request.user
        return super().form_valid(form)
