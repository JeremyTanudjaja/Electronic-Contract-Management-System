from django.urls import path
from . import views

app_name = 'project'

urlpatterns = [
    path('index/', views.index_project, name='index'),
    path('home/', views.ContractListView.as_view(), name='project_home'),
    path('add-project', views.ContractAddView.as_view(), name='project_add'),
    path('project-detail/<slug>', views.ContractProgressionView.as_view(), name='project_detail'),
    path('project-edit/<slug>', views.ContractUpdateView.as_view(), name='project_edit'),

    # Small Function FBV
    path('deactivate-project', views.deactivate_project, name='project_deactivate'),
    path('download_file/', views.download_contract_file, name='download_file'),
    path('update-project-feature', views.update_project_feature, name='update_feature'),
    path('update-project-payment', views.update_payment_terms, name='update_payment'),
    path('upload_file', views.upload_document, name='upload_file'),
    path('update_status', views.update_status, name='update_status'),
    path('send_invoice_creation_signal', views.send_invoice_creation_signal, name='send_invoice_creation_signal'),
    path('get_soi_template', views.download_contract_template, name='download_contract_template'),
    path('prod_done', views.project_dev_done, name='project_dev_done'),
    path('project_closed', views.close_project, name='close_project'),

    # For HTMX
    path('update_contact/', views.update_contact_list, name='update_contact'),
]