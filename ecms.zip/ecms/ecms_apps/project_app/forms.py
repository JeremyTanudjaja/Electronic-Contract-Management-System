from django import forms
from .models import ContractModel, ContractProgression, ContractFeatureDetail
from ecms_apps.customer_app.models import CustomerContactInformation, CustomerInformation
from dynamic_forms import DynamicField, DynamicFormMixin


class ContractModelAdminForm(forms.ModelForm):
    class Meta:
        model = ContractModel
        exclude = ['contract_slug', 'last_update_time', 'created_by', 'last_update_by']

    contract_title = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Contract / Project Title'}
    ))
    contract_value = forms.CharField(required=True, widget=forms.NumberInput(
        attrs={"placeholder": 'Estimated Value AED'}
    ))

    contract_stage = forms.IntegerField(required=False, widget=forms.NumberInput(
        attrs={"placeholder": 'Contract Stage'}))

    contract_summary = forms.CharField(required=True, widget=forms.Textarea(
        attrs={"placeholder": 'Contact Summary', "style": "width: 100%; height: 200px; resize: none;"}
    ))
    requisition_by = forms.ModelChoiceField(queryset=CustomerInformation.objects.all())
    client_contact = forms.ModelChoiceField(queryset=CustomerContactInformation.objects.all())

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class ContractModelAddForm(DynamicFormMixin, forms.ModelForm):

    def contact_choices(form):
        # this function is created to fill the client_contact field dynamically
        # takes in the requisition_by field value and filter the Contact based on
        # the chosen requisition_by field value
        client = form['requisition_by'].value()
        return CustomerContactInformation.objects.filter(company_id=client, contact_active=True)

    def initial_contact(form):
        # same as contact_choices, but here we declare what the first value of the
        # contact field is supposed to be when we first see the page
        client = form['requisition_by'].value()
        return CustomerContactInformation.objects.filter(company_id=client).first()

    contract_title = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Contract / Project Title'}
    ))
    contract_value = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Estimated Value AED', "data-type": 'currency'}
    ))

    contract_summary = forms.CharField(required=True, widget=forms.Textarea(
        attrs={"placeholder": 'Contact Summary', "style": "width: 100%; height: 200px; resize: none;"}
    ))
    requisition_by = forms.ModelChoiceField(queryset=CustomerInformation.objects.all(),
                                            initial=CustomerInformation.objects.first())

    # Use django-forms-dynamic to create a dynamic field, i.e. field that is updated based on
    # another field's value. takes in 3 parameter. first is the form field type from django,
    # queryset which is a queryset object containing object_model and initial, which is the
    # first selected value when we see the field
    client_contact = DynamicField(
        forms.ModelChoiceField,
        queryset=contact_choices,
        initial=initial_contact
    )

    # client_contact = forms.ModelChoiceField(queryset=CustomerContactInformation.objects.none())

    class Meta:
        model = ContractModel
        exclude = ['contract_slug', 'sales_personnel', 'commercial_personnel', 'created_time', 'last_update_time',
                   'created_by', 'last_update_by', 'is_active', 'product_personnel', 'contract_stage', 'dev_stage']

    def clean(self):
        # We added an integer comma separator in the html, so we need to get rid of the
        # commas, dollar, etc. Before we can save it
        cleaned_data = super().clean()
        # print('clean_data in')
        # print(cleaned_data['contract_value'])
        integer_contract_value = float(cleaned_data.get('contract_value').split(".")[0].replace(",", ""))
        # print(integer_contract_value)
        cleaned_data['contract_value'] = integer_contract_value
        return cleaned_data

class ContractSearchForm(forms.Form):
    contract_title = forms.CharField(required=False, widget=forms.TextInput(
        attrs={"placeholder": 'Contract / Project Title', 'name': 'search-project-title', 'id': 'search-project-title'}
    ))

    contract_status_choice = (('-----', '-----'),
                              ('FEASIBILITY ANALYSIS', 'Feasibility Analysis'),
                              ('INITIAL PROPOSAL', 'Initial Proposal'),
                              ('COMMERCIAL ANALYSIS', 'Commercial Analysis'),
                              ('CLIENT DECISION PENDING', 'Client Decision Pending'),
                              ('PROPOSAL IMPROVEMENT', 'Proposal Improvement'),
                              ('PAYMENT TERM ADDED', 'Payment Term Added'),
                              ('FINAL PROPOSAL', 'Final Proposal'),
                              ('FINAL CONTRACT', 'Final Contract'))

    contract_status = forms.ChoiceField(required=False, choices=contract_status_choice)
    client_name = forms.ModelChoiceField(required=False, queryset=CustomerInformation.objects.all(),
                                         initial=CustomerInformation.objects.none())

    contract_type_choice = (('-----', '-----'),
                            ('HEALTHCARE TYPE', 'Healthcare Type'),
                            ('EDUCATION TYPE', 'Education Type'),
                            ('MANUFACTURE TYPE', 'Manufacture Type'),
                            ('FINANCE TYPE', 'Finance Type'))

    contract_type = forms.ChoiceField(required=False, choices=contract_type_choice)


class DocumentAddForm(forms.ModelForm):

    class Meta:
        model = ContractProgression
        exclude = ['old_contract_filename', 'upload_time']


class ContractAddFeatureForm(forms.ModelForm):

    mobile_app = forms.BooleanField(required=False)
    web_app = forms.BooleanField(required=False)
    desktop_app = forms.BooleanField(required=False)
    cloud_service = forms.BooleanField(required=False)
    internet_of_things = forms.BooleanField(required=False)
    data_management_analytics = forms.BooleanField(required=False)
    blockchain = forms.BooleanField(required=False)
    artificial_intelligence = forms.BooleanField(required=False)
    datacenter = forms.BooleanField(required=False)
    disaster_recovery = forms.BooleanField(required=False)
    training = forms.BooleanField(required=False)

    class Meta:
        model = ContractFeatureDetail
        exclude = ['contract_id']


class EditContractInfoForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        requisition_by_company = self.instance.requisition_by
        self.fields['client_contact'].queryset = CustomerContactInformation.objects.filter(
            company_id=requisition_by_company)


    class Meta:
        model = ContractModel
        exclude = ['requisition_by', 'sales_personnel', 'commercial_personnel', 'is_active',
                   'last_update_by', 'contract_id', 'contract_stage', 'contract_status',
                   'contract_slug', 'created_time', 'last_update_time', 'created_by', 'product_personnel',
                   'dev_stage']

    contract_title = forms.CharField(required=True, widget=forms.TextInput(
        attrs={"placeholder": 'Contract / Project Title'}
    ))
    contract_value = forms.CharField(required=True, widget=forms.NumberInput(
        attrs={"placeholder": 'Estimated Value AED'}
    ))
    contract_summary = forms.CharField(required=True, widget=forms.Textarea(
        attrs={"placeholder": 'Contact Summary', "style": "width: 100%; height: 200px; resize: none;"}
    ))
