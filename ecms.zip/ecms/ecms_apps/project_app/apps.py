from django.apps import AppConfig


class ProjectAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ecms_apps.project_app'
