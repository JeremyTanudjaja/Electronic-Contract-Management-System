from celery import shared_task
from django.core.mail import send_mail
from django.conf import settings
from .models import ContractModel, ContractProgression
from datetime import datetime
import pytz


@shared_task(bind=True)
def test_celery_function(self):
    for i in range(0, 6):
        print(i)
    return "Done"


@shared_task(bind=True)
def send_mail_after_upload(self, data: dict, email_to: list) -> str:
    print('Send Email Function')
    mail_subject = 'A New File Upload Has Been Done!'
    message = (f'A new Document Upload has been done with this credential: \n'
               f'Project Title: {data["contract_title"]}. \n'
               f'Client: {data["client_name"]}. \n'
               f'Status: {data["contract_status"]}. \n'
               f'This file upload is completed at {data["time_upload"]}, By: {data["contract_uploader"]}.')

    send_mail(subject=mail_subject,
              message=message,
              from_email=settings.EMAIL_HOST_USER,
              recipient_list=email_to,
              fail_silently=True)
    return "Send Email Done"

@shared_task(bind=True)
def send_email_to_make_invoice(self, data: dict):
    print('Send Email Function To Signal Invoice Creation')
    mail_subject = 'Invoice can be Created!'
    message = (f'A Message from the Product Team, Invoice can now be created for: \n'
               f'Project/Contract: {data["contract_title"]} \n'
               f'Company: {data["requisition_by"]} \n'
               f'For Invoice Stage Number: Invoice Stage {data["invoice_stage"]}')

    send_mail(subject=mail_subject,
              message=message,
              from_email=settings.EMAIL_HOST_USER,
              recipient_list=[data['commercial_personnel_email']],
              fail_silently=True)
    return "Send Email To Start Invoice Creation Done"


@shared_task(bind=True)
def check_last_update_every_week(self):
    all_project = ContractModel.objects.filter(is_active=True)
    for contract_object in all_project:
        # if it hasn't been updated for 7 days

        timezone = pytz.timezone(settings.TIME_ZONE)
        current_datetime = timezone.localize(datetime.now())

        if (current_datetime - contract_object.last_update_time).days > 7:
            # and the contract is not in the FINAL CONTRACT status i.e. it's already done
            if contract_object.contract_status != 'FINAL CONTRACT':
                # the slugs have spaces (My bad), so we replace the space with %20 so that it will be
                # recognized as a link
                slug_for_link = str(contract_object.contract_slug).replace(" ", "%20")
                url_link = f"{settings.SITE_URL}/project/project-detail/{slug_for_link}"
                email_list = [contract_object.commercial_personnel.commercial_staff_id.email,
                              contract_object.sales_personnel.sales_staff_id.email]
                subject = 'Reminder to Update Project Document'
                message = (f"A Project hasn't been updated in a long time. The project in question is: \n"
                           f"Project Name: {contract_object.contract_title} \n"
                           f"Client: {contract_object.requisition_by}\n"
                           f"Current Contract Stage: {contract_object.contract_status}\n"
                           f"Last Updated: {contract_object.last_update_time}\n"
                           f"Accessible: {url_link}\n"
                           f"Please Upload the SOI or Contract Document immediately")
                send_mail(subject=subject,
                          message=message,
                          from_email=settings.EMAIL_HOST_USER,
                          recipient_list=email_list,
                          fail_silently=True)
                print('Project Reminder Email Sent')
            else:
                print('contract already in FINAL CONTRACT Stage')
        else:
            print('Not Yet Time')

@shared_task(bind=True)
def notify_project_production_done(self, project_slug):
    contract_object = ContractModel.objects.get(contract_slug=project_slug)

    email_list = [contract_object.commercial_personnel.commercial_staff_id.email,
                  contract_object.sales_personnel.sales_staff_id.email]

    slug_for_link = str(contract_object.contract_slug).replace(" ", "%20")
    url_link = f"{settings.SITE_URL}/project/project-detail/{slug_for_link}"

    subject = 'Product Team has finished Project Production'
    message = (f"A Project's Development has Finished Completely. The project in question is: \n"
               f"Project Name: {contract_object.contract_title} \n"
               f"Client: {contract_object.requisition_by}\n"
               f"Current Contract Stage: {contract_object.contract_status}\n"
               f"Last Updated: {contract_object.last_update_time}\n"
               f"Accessible: {url_link}\n")
    send_mail(subject=subject,
              message=message,
              from_email=settings.EMAIL_HOST_USER,
              recipient_list=email_list,
              fail_silently=True)
    return 'send production finished notification has been completed'


@shared_task(bind=True)
def notify_project_closing(self, project_slug, user: str):
    contract_object = ContractModel.objects.get(contract_slug=project_slug)

    email_list = [contract_object.commercial_personnel.commercial_staff_id.email,
                  contract_object.sales_personnel.sales_staff_id.email]

    subject = 'Project has Been Finished and is Closed'
    message = (f"A Project's Development has Finished Completely. The project in question is: \n"
               f"Project Name: {contract_object.contract_title} \n"
               f"Client: {contract_object.requisition_by}\n"
               f"Closed By: {user}\n")
    send_mail(subject=subject,
              message=message,
              from_email=settings.EMAIL_HOST_USER,
              recipient_list=email_list,
              fail_silently=True)

    return 'send project closing notification has been completed'
