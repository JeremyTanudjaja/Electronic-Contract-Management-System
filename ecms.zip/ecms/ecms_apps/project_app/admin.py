from django.contrib import admin
from .models import ContractModel, ContractProgression, ContractFeatureDetail
from .forms import ContractModelAdminForm


class ContractAdmin(admin.ModelAdmin):
    form = ContractModelAdminForm
    list_filter = ['contract_status']
    search_fields = ['contract_title']


class ContractProgressionAdmin(admin.ModelAdmin):
    list_filter = ['contract_status']


# Register your models here.
admin.site.register(ContractModel, ContractAdmin)
admin.site.register(ContractProgression)
admin.site.register(ContractFeatureDetail)
