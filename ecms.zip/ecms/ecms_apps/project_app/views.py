import os
from datetime import datetime

from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ObjectDoesNotExist, MultipleObjectsReturned

from django.http import HttpResponse, FileResponse, Http404
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import TemplateView, ListView, CreateView, DetailView, UpdateView
from .models import ContractModel, ContractProgression
from .forms import ContractModelAddForm, ContractSearchForm, DocumentAddForm, ContractAddFeatureForm, \
    EditContractInfoForm
from ecms_apps.user_app.models import Commercial, Sales, ProductContact
from ecms_apps.customer_app.models import CustomerInformation
from ecms_apps.invoice_app.models import InvoiceModel, InvoiceModelDetail
from django.db.models.query import QuerySet
from django.conf import settings
from django_htmx.http import HttpResponseClientRefresh
from django.contrib import messages
from django.utils import timezone
from . import tasks


# Create your views here.
@login_required
def index_project(request):
    return render(request, 'project_page/index.html')


class ContractListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = ContractModel
    template_name = 'project_page/project_home.html'
    paginate_by = 5

    permission_required = ['project_app.view_contractmodel']

    def dispatch(self, request, *args, **kwargs):
        print(request.user.has_perm('project_app.view_contractmodel'))
        return super(ContractListView, self).dispatch(request, *args, **kwargs)

    def get_search_query(self, query_set: QuerySet):
        # check if the method is GET
        if self.request.method == 'GET':
            # check if it is the search form that creates the request via
            # the search-form name value that we insert into the submit button
            if 'search_form_submit' in self.request.GET:
                # if there is a contract_title value
                # print(self.request.GET)
                if self.request.GET.get('contract_title'):
                    query_set = query_set.filter(contract_title__icontains=self.request.GET.get('contract_title'))
                if self.request.GET.get('contract_status') != '-----':
                    query_set = query_set.filter(contract_status__icontains=self.request.GET.get('contract_status'))
                if self.request.GET.get('client_name'):
                    client = CustomerInformation(company_id=self.request.GET.get('client_name'))
                    query_set = query_set.filter(requisition_by=client)
                if self.request.GET.get('contract_type') != '-----':
                    query_set = query_set.filter(contract_type__icontains=self.request.GET.get('contract_type'))
        # print(query_set)
        return query_set

    def user_filter(self, query_set: QuerySet) -> QuerySet:
        if self.request.user.role == 'COMMERCIAL':
            commercial_personnel = Commercial.objects.get(commercial_staff_id=self.request.user)
            query_set = query_set.filter(commercial_personnel=commercial_personnel)
        elif self.request.user.role == 'SALES':
            sales_personnel = Sales.objects.get(sales_staff_id=self.request.user)
            query_set = query_set.filter(sales_personnel=sales_personnel)
        elif self.request.user.role == 'PRODUCT':
            product_personnel = ProductContact.objects.get(product_team_id=self.request.user)
            query_set = query_set.filter(product_personnel=product_personnel)
        else:
            pass
        return query_set

    def get_queryset(self):
        query_set = super().get_queryset()
        query_set = query_set.filter(is_active=True)
        query_set = self.user_filter(query_set=query_set)
        query_set = self.get_search_query(query_set)
        query_set = query_set.order_by('-created_time')
        return query_set

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_form'] = ContractSearchForm
        return context


class ContractProgressionView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    template_name = 'project_page/project_progression_page.html'
    context_object_name = 'this_project_detail'
    slug_field = 'contract_slug'
    model = ContractModel

    permission_required = ['project_app.view_contractmodel',
                           'project_app.change_contractmodel',
                           'project_app.view_contractprogression',
                           'project_app.change_contractprogression']

    def get_queryset(self):
        # get the query set, i.e. the particular object that we want using
        # the slug value that is parsed via the url params defined in the urls.py file
        queryset = super().get_queryset()
        return queryset.filter(contract_slug__iexact=self.kwargs.get('slug'))

    def get_context_data(self, **kwargs):
        # first get the original context. the original context has a 'project_detail' key
        # the data from this key is the queryset result that we defined earlier
        context = super().get_context_data(**kwargs)

        # we grab the reverse relation of the object that is the contract_progression_detail object
        # this object is filled with the stored document for each contract/project and it's status
        contract_progression = context['this_project_detail'].contract_progression_detail.all()
        try:
            payment_term = InvoiceModel.objects.get(contract_id=context['this_project_detail']).max_invoice_stage
        except ObjectDoesNotExist:
            pass
        else:
            context['payment_term'] = payment_term
            context['current_dev_stage'] = context['this_project_detail'].dev_stage - 1

        # now we split it to each status because we want to display documents according to the status
        # this will create many context data, but I believe it will make development easier
        context['feasibility_analysis'] = contract_progression.filter(
            contract_status__iexact='FEASIBILITY ANALYSIS').order_by('-upload_time')
        context['initial_proposal'] = contract_progression.filter(contract_status__iexact='INITIAL PROPOSAL').order_by(
            '-upload_time')
        context['commercial_analysis'] = contract_progression.filter(
            contract_status__iexact='COMMERCIAL ANALYSIS').order_by('-upload_time')
        context['client_decision_pending'] = contract_progression.filter(
            contract_status__iexact='CLIENT DECISION PENDING').order_by('-upload_time')
        context['proposal_improvement'] = contract_progression.filter(
            contract_status__iexact='PROPOSAL IMPROVEMENT').order_by('-upload_time')
        context['payment_term_added'] = contract_progression.filter(
            contract_status__iexact='PAYMENT TERM ADDED').order_by('-upload_time')
        context['final_proposal'] = contract_progression.filter(contract_status__iexact='FINAL PROPOSAL').order_by(
            '-upload_time')
        context['final_contract'] = contract_progression.filter(contract_status__iexact='FINAL CONTRACT').order_by(
            '-upload_time')
        # print(context['feasibility_analysis'])
        return context


class ContractUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = ContractModel
    template_name = 'project_page/project_information_edit.html'
    slug_field = 'contract_slug'
    form_class = EditContractInfoForm
    context_object_name = 'this_project_detail'

    permission_required = ['project_app.view_contractmodel',
                           'project_app.change_contractmodel']

    def get_success_url(self):
        return reverse_lazy('project:project_detail', kwargs={'slug': self.kwargs['slug']})

    def form_invalid(self, form):
        print(form.errors)


@login_required
def deactivate_project(request):
    if request.method == 'POST':
        contract_model = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))
        contract_model.is_active = False
        contract_model.save()
    return redirect('project:project_home')


@login_required
def download_contract_file(request):
    """This is a request method that is used as an endpoint to download a file
    it takes in a filepath with the method POST where the filepath is the partial
    filepath of the file that we want to download"""
    if request.POST:
        # get the file path
        file = request.POST.get('filepath')

        # get the file path name
        file_name = str(file).split('/')[-1]
        # print(file_name)

        # join the partial file path with the media_root path from the settings.py
        # to create a full file path. We need a full file path to get the document
        file_path = os.path.join(settings.MEDIA_ROOT, file)

        # check if the document exist
        if os.path.exists(file_path):
            print('file exists')

            # we then need to open the document, we set it as read-binary to handle
            # text and images if there are any
            with open(file_path, 'rb') as f:
                # insert the data inside a variable and open it
                data = f.read()

            # configure the response, we insert the data and what type of content inside of it
            # for spreadsheet and mp4, the content_type is different
            response = HttpResponse(data, content_type='application/octet-stream')
            # we add a dictionary containing metadata, this is required
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'

            # we update the last contract accessor
            # first we get the corresponding contract parent object
            contract_slug = request.POST.get('contract_slug')
            print(contract_slug)
            contractmodelobject = ContractModel.objects.get(contract_slug__iexact=contract_slug)

            # then we get the contractprogressionobject and we update it
            progression_object = ContractProgression.objects.get(contract_id=contractmodelobject,
                                                                 contract_file__iexact=file)
            progression_object.last_contract_accessor = request.user
            progression_object.save()
            return response
        raise Http404


@login_required
def download_contract_template(request):
    if request.POST:
        file = request.POST.get('filepath')
        print(file)
        file_name = str(file).split('/')[-1]
        file_path = os.path.join(settings.STATICFILES_DIRS[0], file)
        print(file_path)
        if os.path.exists(file_path):
            print('exist')
            with open(file_path, 'rb') as f:
                # insert the data inside a variable and open it
                data = f.read()
            response = HttpResponse(data, content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
        raise Http404


@login_required
def upload_document(request):
    """This function is called from a htmx post request. It is responsible for
    file upload. the form input in the template is comprised of a POST request and a FILE request
    The POST request is basically a hidden input field containing the contract object and status"""
    if request.htmx:
        # check if the user inserted a file, if there isn't any then the request won't be processed
        if request.FILES.get('contract_file'):
            # get the contract object using the slug that we passed via hidden POST field
            parent = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))

            # parse it into a dictionary, the keys are the field name inside the form. We are using
            # a modelForm so the field name is just the model field name
            data = {'contract_id': parent,
                    'contract_status': request.POST.get('status'),
                    'contract_uploader': request.user,
                    'last_contract_accessor': request.user}
            # one of the field is a FileField, so we need to input a FILE into it. we get
            # the file from the request.FILES. Again we need to turn it into a dictionary
            file_data = {'contract_file': request.FILES.get('contract_file')}

            # we input the datas into the Form. We do this so that we can leverage django's form validation
            form = DocumentAddForm(data, files=file_data)

            # just some lines to check if the data is inputted correctly, if the form is valid, if there are errors
            # print(form.is_bound)
            # print(form.is_valid())
            # print(form.errors)

            # save the form. This will save the data into our database
            form.save()
            messages.success(request, 'File Upload Successful')

            # update the contract object, there is a last updated by and last update time field in
            # the contract object that we need to also update
            parent.last_update_by = request.user
            parent.last_update_time = datetime.now()
            parent.save()
            # Render the new progression, because we have just update the document we need to render the new
            # document. Since this is a htmx request, we can just use the usual partial update that was given
            # from the htmx
            progression = ContractProgression.objects.filter(contract_id=parent,
                                                             contract_status__iexact=request.POST.get(
                                                                 'status')).order_by('-upload_time')

            # Send Email to Commercial and Sales after a new upload file
            tasks.send_mail_after_upload.delay(
                data={'contract_title': parent.contract_title,
                      'client_name': parent.requisition_by.company_name,
                      'contract_status': request.POST.get('status'),
                      'contract_uploader': f"{request.user.first_name} {request.user.last_name}",
                      'time_upload': datetime.now().strftime("%A %d %B %Y, %H:%M:%S")},
                email_to=[parent.commercial_personnel.commercial_staff_id.email,
                          parent.sales_personnel.sales_staff_id.email])
            print(parent.contract_slug)
            return render(request, 'project_page/progression_htmx/update_progression.html',
                          context={'object_list': progression, 'this_project_detail': parent})
        else:
            print('no-document')
    raise Http404


@login_required
def update_status(request):
    """This function is called to update the contract status when the user clicks on the next stage
    button in the document list template. It will update the status string and status stage int that
    is stored inside our db. It will first check whether the status update is valid or not. status
    cannot be reverted i.e. from commercial analysis to feasibility. The validity check is done using
    the stage int"""
    # Template sends 3 POST value from a hidden input field that is the status string, contract slug and the
    # stage integer. The status string is the target string that we want to update to, while the
    # stage integer is the current contract stage integer i.e. if it is feasibility analysis then
    # the stage integer is 0
    if request.POST:
        # get the object associated with the slug that we sent. The slug is a value from our detailView
        # the slug is stored inside a hidden POST value called 'parent object'
        contract_object = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))

        # checks if there is a document in the status progression
        pass_status = {'CLIENT DECISION PENDING', 'PROPOSAL IMPROVEMENT', 'FEASIBILITY ANALYSIS', 'PAYMENT TERM ADDED'}
        print(request.POST.get('current_status'))
        if request.POST.get('current_status') not in pass_status:
            try:
                contract_status_progression = ContractProgression.objects.get(contract_id=contract_object,
                                                                              contract_status=request.POST.get('current_status'))
            except ObjectDoesNotExist:
                messages.add_message(request, messages.INFO, extra_tags='no-file',
                                     message="Document has not been uploaded, Please Upload SOI Document to the "
                                             "System via the upload document")
                return render(request, 'project_page/progression_htmx/update_progression.html',
                              context={'object_list': False, 'this_project_detail': contract_object})
            except MultipleObjectsReturned:
                pass
        # get the stored contract stage value in the db and compare it with the sent contract stage value
        # from our POST request. If the request is higher than the stored db then the stage is valid
        # remember that we can only update the stage forward and not backward
        if int(request.POST.get('contract_stage')) >= contract_object.contract_stage:
            print('status stage valid')
            # update the stage by incrementing the value and update the status via the status POST value
            # remember that the sent POST value is our target POST value, so we do not need to change anything
            contract_object.contract_stage = int(request.POST.get('contract_stage')) + 1
            contract_object.contract_status = request.POST.get('contract_status')

            # update the contract object, there is a last updated by and last update time field in
            # the contract object that we need to also update (this is untested)
            contract_object.last_update_by = request.user
            contract_object.last_update_time = datetime.now()
            contract_object.save()
        else:
            print('status stage not valid')
            # refresh the page after a status change
        return HttpResponseClientRefresh()


def update_status_project_feature_and_payment(data: dict) -> None:
    # This is the same as the update_status code, but it is made to update the status
    # from a special updator
    contract_object = ContractModel.objects.get(contract_slug__iexact=data['parent_object'])

    if int(data['contract_stage']) >= contract_object.contract_stage:
        print('status stage valid')

        contract_object.contract_stage = int(data['contract_stage']) + 1
        contract_object.contract_status = data['contract_status']
        contract_object.last_update_by = data['user']
        contract_object.last_update_time = datetime.now()

        contract_object.save()
    else:
        print('status stage not valid')


@login_required
@permission_required(['project_app.view_contractfeaturedetail',
                      'project_app.change_contractfeaturedetail',
                      'project_app.add_contractfeaturedetail'], raise_exception=True)
def update_project_feature(request):
    if request.method == 'POST':
        if request.POST.get('submit-button'):
            # create an if to check the document here, tba tomorrow, redirect to the add feature page
            # with a new message
            parent = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))
            try:
                contract_document = ContractProgression.objects.get(contract_id=parent,
                                                                       contract_status='FEASIBILITY ANALYSIS')
            except ObjectDoesNotExist:
                messages.add_message(request, messages.INFO, extra_tags='no-file',
                                     message="Document has not been uploaded, Please Upload SOI Document to the "
                                             "System via the upload document")
                context = {'form': ContractAddFeatureForm,
                           'contract_status': request.POST.get('contract_status'),
                           'contract_stage': request.POST.get('contract_stage'),
                           'parent_object': request.POST.get('parent_object')}
                return render(request, template_name='project_page/project_add_feature.html', context=context)
            except MultipleObjectsReturned:
                pass
            data = {'mobile_app': request.POST.get('mobile_app'),
                    'web_app': request.POST.get('web_app'),
                    'desktop_app': request.POST.get('desktop_app'),
                    'cloud_service': request.POST.get('cloud_service'),
                    'internet_of_things': request.POST.get('internet_of_things'),
                    'data_management_analytics': request.POST.get('data_management_analytics'),
                    'blockchain': request.POST.get('blockchain'),
                    'artificial_intelligence': request.POST.get('artificial_intelligence'),
                    'datacenter': request.POST.get('datacenter'),
                    'disaster_recovery': request.POST.get('disaster_recovery'),
                    'training': request.POST.get('training')}
            print(data)
            form = ContractAddFeatureForm(data=data)

            if form.is_valid():
                ContractParent = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))
                form.instance.contract_id = ContractParent
                form.save()
                update_status_data = {'parent_object': request.POST.get('parent_object'),
                                      'contract_stage': request.POST.get('contract_stage'),
                                      'contract_status': request.POST.get('contract_status'),
                                      'user': request.user}
                update_status_project_feature_and_payment(update_status_data)
                return redirect('project:project_detail', slug=request.POST.get('parent_object'))
        else:
            print('masuk create form')
            context = {'form': ContractAddFeatureForm,
                       'contract_status': request.POST.get('contract_status'),
                       'contract_stage': request.POST.get('contract_stage'),
                       'parent_object': request.POST.get('parent_object')}
    return render(request, template_name='project_page/project_add_feature.html', context=context)


def create_payment_term_and_detail(data: dict):
    # print(data)
    contract_parent = ContractModel.objects.get(contract_slug__iexact=data['project_slug'])
    invoice_model = InvoiceModel.objects.create(
        contract_id=contract_parent,
        max_invoice_stage=data['term_quantity'],
        current_due_date=data['payment_date'][0]
    )
    for i in range(0, int(data['term_quantity'])):
        # print(data['payment_percentage'][i])
        payment_percentage = float(data['payment_percentage'][i]) / 100
        payment_value = int(payment_percentage * data['contract_value'])
        payment_after_tax = int(((payment_value * 11) / 100) + payment_value)

        # detail data creation
        invoice_model_detail = InvoiceModelDetail.objects.create(
            invoice_id=invoice_model,
            invoice_stage=i + 1,
            payment_percentage=payment_percentage,
            payment_value=payment_value,
            payment_after_tax=payment_after_tax,
            due_date=data['payment_date'][i]
        )


@login_required
@permission_required(['invoice_app.view_invoicemodel',
                      'invoice_app.add_invoicemodel',
                      'invoice_app.change_invoicemodel',
                      'invoice_app.view_invoicemodeldetail',
                      'invoice_app.add_invoicemodeldetail',
                      'invoice_app.change_invoicemodeldetail'], raise_exception=True)
def update_payment_terms(request):
    if request.method == 'POST':
        contract_object = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))
        if contract_object.contract_stage != 5:
            return redirect('project:project_detail', slug=request.POST.get('parent_object'))
        if request.POST.get('submit-button'):
            # print('masuk submit')
            # create an if to check the document here, tba tomorrow, redirect to the add feature page
            # with a new message
            try:
                contract_document = ContractProgression.objects.get(contract_id=contract_object,
                                                                    contract_status='PAYMENT TERM ADDED')
            except ObjectDoesNotExist:
                messages.add_message(request, messages.INFO, extra_tags='no-file',
                                     message="Document has not been uploaded, Please Upload SOI Document to the "
                                             "System via the upload document")
                context = {'contract_status': request.POST.get('contract_status'),
                           'contract_stage': request.POST.get('contract_stage'),
                           'parent_object': request.POST.get('parent_object'),
                           'contract_object': contract_object}
                return render(request, template_name='project_page/project_add_payment_term.html', context=context)
            except MultipleObjectsReturned:
                pass
            update_payment_term_data = {'project_slug': request.POST.get('parent_object'),
                                        'term_quantity': request.POST.get('qty'),
                                        'payment_percentage': request.POST.getlist('payment_percentage'),
                                        'payment_date': request.POST.getlist('payment_date'),
                                        'contract_value': contract_object.contract_value}
            create_payment_term_and_detail(update_payment_term_data)

            update_status_data = {'parent_object': request.POST.get('parent_object'),
                                  'contract_stage': request.POST.get('contract_stage'),
                                  'contract_status': request.POST.get('contract_status'),
                                  'user': request.user}
            update_status_project_feature_and_payment(update_status_data)
            return redirect('project:project_detail', slug=request.POST.get('parent_object'))
        else:
            context = {'contract_status': request.POST.get('contract_status'),
                       'contract_stage': request.POST.get('contract_stage'),
                       'parent_object': request.POST.get('parent_object'),
                       'contract_object': contract_object}
    return render(request, template_name='project_page/project_add_payment_term.html', context=context)


@login_required
def send_invoice_creation_signal(request):
    # this is for sending invoice creation signal and is used by the prod team.
    # when prod team has finished development up to a certain point as is explained in the
    # contract, let's say after 30% development done, first invoice will be billed.
    # This function will send an email to the commercial team to send the invoice to the
    # invoicing team. It will also update the dev_done attribute that explains the current
    # development stage. This stage info is used when sending the email to let the commercial personnel
    # know how far the project dev has progressed in terms of when we can bill the client. The dev_done
    # attribute is also used when closing the project, to make sure that the project's dev has reached
    # its final term
    if request.method == 'POST':
        contract_model = ContractModel.objects.get(contract_slug__iexact=request.POST.get('parent_object'))
        invoice_model = InvoiceModel.objects.get(contract_id=contract_model)

        data = {'commercial_personnel_email': contract_model.commercial_personnel.commercial_staff_id.email,
                'contract_title': contract_model.contract_title,
                'requisition_by': contract_model.requisition_by.company_name,
                'invoice_stage': contract_model.dev_stage}
        print(data)

        # if the current dev_stage is still smaller than the maximum invoice stage
        # remember the dev stage is a representation of development progress in regards to payment
        # that is described in the contract
        # for example
        # if the first payment is billed when project is 30% completed,
        # then the dev_stage for 30% completed is dev_stage 1
        if contract_model.dev_stage <= invoice_model.max_invoice_stage:
            print('add +1 to dev stage')
            contract_model.dev_stage = contract_model.dev_stage + 1
            contract_model.save()
            tasks.send_email_to_make_invoice.delay(data=data)
        else:
            print('Too much')

        return redirect('project:project_detail', slug=request.POST.get('parent_object'))


class ContractAddView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = ContractModel
    template_name = 'project_page/project_add.html'
    form_class = ContractModelAddForm
    success_url = 'home/'

    permission_required = ['project_app.view_contractmodel',
                           'project_app.change_contractmodel',
                           'project_app.add_contractmodel']

    def get_least_working_commercial(self):
        """Get the Least Working Commercial Personnel"""
        # Get the Commercial Staff with the least amount of work
        least_working_commercial = Commercial.objects.order_by('projects_assigned', 'total_project_assigned').first()

        # Update the total number of project worked by the staff
        least_working_commercial.projects_assigned = least_working_commercial.projects_assigned + 1
        least_working_commercial.total_project_assigned = least_working_commercial.total_project_assigned + 1
        least_working_commercial.save()

        # return the commercial staff
        return least_working_commercial

    def get_least_working_product(self):
        least_working_product = ProductContact.objects.order_by('projects_assigned', 'total_project_assigned').first()

        least_working_product.projects_assigned = least_working_product.projects_assigned + 1
        least_working_product.total_project_assigned = least_working_product.total_project_assigned + 1
        least_working_product.save()

        return least_working_product

    def update_sales_project_count(self, sales_staff):
        # just grabs the corresponding sales_staff that we sent and adds +1 to their project count
        sales_staff.projects_assigned = sales_staff.projects_assigned + 1
        sales_staff.total_project_assigned = sales_staff.total_project_assigned + 1
        sales_staff.save()

    def form_valid(self, form):
        print('form valid')
        # if the form is valid, insert the current user as the user
        # that initially creates and updates the Contract. we do not define
        # this field in the forms.py so we need to input it via code
        form.instance.created_by = self.request.user
        form.instance.last_update_by = self.request.user

        # we also need to input the corresponding sales_staff that creates this contract.
        # only sales can create a new contract entry so we can just use the created_by field
        # i.e. our current user for this field. We first need to get the sales staff object
        sales_staff = Sales.objects.get(sales_staff_id=self.request.user)
        # input it into the form
        form.instance.sales_personnel = sales_staff

        # now we need to update the sales staff project count
        self.update_sales_project_count(sales_staff=sales_staff)

        # get the least working commercial personnel i.e. personnel with the lowest work load
        # and assign the personnel to the project/contract
        least_working_commercial = self.get_least_working_commercial()
        least_working_product = self.get_least_working_product()

        form.instance.commercial_personnel = least_working_commercial
        form.instance.product_personnel = least_working_product

        return super().form_valid(form)

    def form_invalid(self, form):
        print('form invalid')
        return super().form_invalid(form)


@login_required
def update_contact_list(request):
    # We create a view to use HTMX. This view is responsible to
    # update the PIC dropdown based on the request value. The request
    # value that is sent to this view is the CustomerInformation Object via a GET
    # request. The request is triggered from our project_add view, from the
    # requisition_by field which is filled with the CustomerInformation Object
    form = ContractModelAddForm(request.GET)
    return HttpResponse(form['client_contact'])


def project_dev_done(request):
    # This code will update the contract model. This will update the project_dev_done attribute
    # that tells us whether the prod team has finished development or not. It will first check
    # if the dev_stage attribute has reached it's max value i.e. it describes whether the project
    # is done or not, if it is then it will set the project_dev_done attribute to True
    # meaning prod team has finished all development and it will notify sales and commercial
    # that the project is finished
    if request.POST:
        contract_model = ContractModel.objects.get(contract_slug=request.POST.get('parent_object'))
        invoice_model = InvoiceModel.objects.get(contract_id=contract_model)
        if invoice_model.max_invoice_stage <= contract_model.dev_stage:
            contract_model.project_dev_done = True
            contract_model.save()
            # Send Email Notification To All Parties that the production team has completed the development
            tasks.notify_project_production_done.delay(project_slug=request.POST.get('parent_object'))
            return redirect('project:project_detail', slug=request.POST.get('parent_object'))
        else:
            messages.add_message(request, messages.INFO, extra_tags='progress-invoice-creation',
                                 message="You haven't progress the 'signal invoice creation'. Thus project cannot be "
                                         "set as done ")
            return redirect('project:project_detail', slug=request.POST.get('parent_object'))


def close_project(request):
    """Method to Close the Project. Checks if all the document is in the system,
    Checks whether invoicing is finished or not, Check if project development is Done
    Then updates the is_complete attribute and notify user that the project is closed"""
    contract_model = ContractModel.objects.get(contract_slug=request.POST.get('parent_object'))
    dont_close_project = False

    # check if contract is in the system and update the all_document_submit attribute
    try:
        contract_document = ContractProgression.objects.filter(contract_id=contract_model,
                                                               contract_status='FINAL CONTRACT').first()
    # If it does not exist, I.E. No Contract then project cannot be closed
    except ObjectDoesNotExist:
        dont_close_project = True
        messages.add_message(request, messages.INFO, extra_tags='no-contract',
                             message="Contract not detected in System, Please Upload Contract Document to Final "
                                     "Contract Section of The Document Upload ")
    else:
        # update all document submit attribute to True. Meaning contract is in the system already
        contract_model.all_document_submit = True
        contract_model.save()

    # check if invoice is finished
    invoice_model = InvoiceModel.objects.get(contract_id=contract_model)
    if not invoice_model.invoicing_done:
        dont_close_project = True
        messages.add_message(request, messages.INFO, extra_tags='invoice-not-done',
                             message="Invoicing is Not Yet Finished, If it should be finished "
                                     "Please contact the commercial personnel responsible for "
                                     "this project")

    # check if project done
    if not contract_model.project_dev_done:
        dont_close_project = True
        messages.add_message(request, messages.INFO, extra_tags='dev-not-done',
                             message="Project Technical Development is not finished yet,"
                                     "If it should've already been finished, please contact "
                                     "The product team responsible for this project")

    # Update to project complete (closing), status change to Close and email notification
    if dont_close_project:
        return redirect('project:project_detail', slug=request.POST.get('parent_object'))
    else:
        # Update the attribute defining contract_status to Closed and is_complete to True
        # It means that the project/contract is finished
        contract_model.is_complete = True
        contract_model.contract_status = 'FINISHED'
        contract_model.save()

        user = f"{request.user.first_name} {request.user.last_name}"
        tasks.notify_project_closing.delay(project_slug=request.POST.get('parent_object'), user=user)

        return redirect('project:project_detail', slug=request.POST.get('parent_object'))
