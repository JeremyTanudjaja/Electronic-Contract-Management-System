from django.db import models
from datetime import datetime
from django.utils.text import slugify
from django.utils.crypto import get_random_string


# Create your models here.
class ContractModel(models.Model):
    class ContractType(models.TextChoices):
        HEALTHCARE = 'HEALTHCARE TYPE', 'Healthcare Type'
        EDUCATION = 'EDUCATION TYPE', 'Education Type'
        MANUFACTURE = 'MANUFACTURE TYPE', 'Manufacture Type'
        FINANCE = 'FINANCE TYPE', 'Finance Type'

    class StatusType(models.TextChoices):
        FEASIBILITY_ANALYSIS = 'FEASIBILITY ANALYSIS', 'Feasibility Analysis'
        INITIAL_PROPOSAL = 'INITIAL PROPOSAL', 'Initial Proposal'
        COMMERCIAL_ANALYSIS = 'COMMERCIAL ANALYSIS', 'Commercial Analysis'
        CLIENT_DECISION_PENDING = 'CLIENT DECISION PENDING', 'Client Decision Pending'
        PROPOSAL_IMPROVEMENT = 'PROPOSAL IMPROVEMENT', 'Proposal Improvement'
        PAYMENT_TERM_SUBMISSION = 'PAYMENT TERM ADDED', 'Payment Term Added'
        FINAL_PROPOSAL = 'FINAL PROPOSAL', 'Final Proposal'
        FINAL_CONTRACT = 'FINAL CONTRACT', 'Final Contract'
        DONE = 'FINISHED', 'finished'

    class Meta:
        verbose_name = 'Contract'
        verbose_name_plural = 'Contract List'

    contract_id = models.BigAutoField(primary_key=True)
    contract_title = models.CharField(max_length=255)
    contract_value = models.FloatField(max_length=255, null=True)
    contract_type = models.CharField(max_length=255, choices=ContractType.choices)
    contract_status = models.CharField(max_length=255, choices=StatusType.choices)
    contract_stage = models.IntegerField(null=True)
    contract_slug = models.SlugField(max_length=255, null=True)
    contract_summary = models.TextField(null=True)

    commercial_personnel = models.ForeignKey('user_app.Commercial', on_delete=models.RESTRICT,
                                             related_name='commercial_staff')
    sales_personnel = models.ForeignKey('user_app.Sales', on_delete=models.RESTRICT,
                                        related_name='sales_staff')
    product_personnel = models.ForeignKey('user_app.ProductContact', on_delete=models.RESTRICT,
                                          related_name='product_staff', null=True)

    requisition_by = models.ForeignKey('customer_app.CustomerInformation', on_delete=models.RESTRICT,
                                       related_name='client_requisition')
    client_contact = models.ForeignKey('customer_app.CustomerContactInformation', on_delete=models.RESTRICT,
                                       related_name='client_contact')

    created_time = models.DateTimeField(default=datetime.now, null=True)
    last_update_time = models.DateTimeField(default=datetime.now, null=True)
    created_by = models.ForeignKey('user_app.ECMS_User', on_delete=models.RESTRICT,
                                   related_name='user_contract_creator')
    last_update_by = models.ForeignKey('user_app.ECMS_User', on_delete=models.RESTRICT,
                                       related_name='user_contract_updator')

    boolean_field_choice = ((None, ''), (True, 'True'), (False, 'False'))
    is_active = models.BooleanField(choices=boolean_field_choice, null=True, default=True)
    is_complete = models.BooleanField(null=True, default=False)
    project_dev_done = models.BooleanField(null=True, default=False)
    all_document_submit = models.BooleanField(null=True, default=False)
    dev_stage = models.IntegerField(null=True, default=1)

    def set_contract_stage(self, *args, **kwargs):
        # the contract_stage field will be used to show the contract progression
        if self.contract_status == 'FEASIBILITY ANALYSIS':
            return 0
        elif self.contract_status == 'INITIAL PROPOSAL':
            return 1
        elif self.contract_status == 'COMMERCIAL ANALYSIS':
            return 2
        elif self.contract_status == 'CLIENT DECISION PENDING':
            return 3
        elif self.contract_status == 'PROPOSAL IMPROVEMENT':
            return 4
        elif self.contract_status == 'PAYMENT TERM ADDED':
            return 5
        elif self.contract_status == 'FINAL PROPOSAL':
            return 6
        else:
            return 7

    def save(self, *args, **kwargs):
        # if it is a new entry then create a new slug,
        # we assumed all data already have a slug
        if not self.contract_id or not self.contract_slug:
            contract_title = str(self.contract_title).replace(' ', '-')
            slug_text = f"{contract_title}-{self.contract_type}-{self.requisition_by}"
            self.contract_slug = slug_text
        self.contract_stage = self.set_contract_stage(*args, **kwargs)
        return super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.contract_title}-{self.contract_type}-{self.requisition_by}"


class ContractProgression(models.Model):

    def upload_directory(instance, filename):
        random = get_random_string(4, 'ABCDEFGHIJKLMNOPQRSTUWVXYZ')
        filename = f"{random}-{filename}"
        return (
            f"{instance.contract_id.requisition_by}/{instance.contract_id.contract_type}/{instance.contract_id.contract_title}"
            f"/{instance.contract_status}/{filename}")

    contract_id = models.ForeignKey(ContractModel, on_delete=models.RESTRICT,
                                    related_name='contract_progression_detail')
    contract_status = models.CharField(max_length=255, choices=ContractModel.StatusType.choices)
    contract_file = models.FileField(upload_to=upload_directory, null=True, max_length=255)
    old_contract_filename = models.CharField(max_length=255, null=True)
    contract_uploader = models.ForeignKey('user_app.ECMS_User', related_name='contract_uploader',
                                          on_delete=models.RESTRICT)
    last_contract_accessor = models.ForeignKey('user_app.ECMS_User', related_name='last_contract_accessor',
                                               on_delete=models.RESTRICT, null=True)
    upload_time = models.DateTimeField(default=datetime.now)

    class Meta:
        verbose_name = 'Contract Progression'
        verbose_name_plural = 'Contract Progression List'

    def __str__(self):
        return f"{self.contract_id.contract_title}-{self.contract_id}-{self.contract_status}-{self.id}"

    def save(self, *args, **kwargs):
        self.old_contract_filename = str(self.contract_file.name).split('/')[-1]
        return super().save(*args, **kwargs)


class ContractFeatureDetail(models.Model):
    contract_id = models.OneToOneField(ContractModel, on_delete=models.RESTRICT, related_name='contract_feature_detail')
    mobile_app = models.BooleanField(null=True, default=False)
    web_app = models.BooleanField(null=True, default=False)
    desktop_app = models.BooleanField(null=True, default=False)
    cloud_service = models.BooleanField(null=True, default=False)
    internet_of_things = models.BooleanField(null=True, default=False)
    data_management_analytics = models.BooleanField(null=True, default=False)
    blockchain = models.BooleanField(null=True, default=False)
    artificial_intelligence = models.BooleanField(null=True, default=False)
    datacenter = models.BooleanField(null=True, default=False)
    disaster_recovery = models.BooleanField(null=True, default=False)
    training = models.BooleanField(null=True, default=False)

    def __str__(self):
        return f"{self.contract_id}"
