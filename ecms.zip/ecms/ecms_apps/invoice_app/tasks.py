import os, mimetypes

from celery import shared_task
from django.core.exceptions import ObjectDoesNotExist
from django.core.mail import EmailMessage, send_mail
from django.conf import settings
from .models import InvoiceModel, InvoiceModelDetail
from datetime import datetime
import pytz


@shared_task(bind=True)
def send_mail_to_invoice(self, invoice_document_pk, user_cred: str) -> bool:
    print('Send Email Function')

    invoice_document = InvoiceModelDetail.objects.get(pk=invoice_document_pk)
    invoice_parent = invoice_document.invoice_id

    invoice_team_email = ['jeremytanudjaja@gmail.com']
    from_email = settings.EMAIL_HOST_USER
    subject = "Invoice is ready to be sent to Client"
    message = (f"Invoice is created and ready to be billed to Client with this information: \n"
               f"Project Name: {invoice_parent.contract_id.contract_title} \n"
               f"Client Name: {invoice_parent.contract_id.requisition_by} \n"
               f"Invoice Value: {invoice_document.payment_value} (AED) \n"
               f"Billed Invoice Value (Tax Added) {invoice_document.payment_after_tax} (AED) \n"
               f"Invoice Creation Date: {invoice_document.due_date} | Invoice needs to be billed before "
               f"1 month has passed \n"
               f"This Invoice has this personnel information: \n"
               f"Sales: {invoice_parent.contract_id.sales_personnel} | "
               f"Commercial: {invoice_parent.contract_id.commercial_personnel} | "
               f"Client Contact: {invoice_parent.contract_id.client_contact} \n"
               f"User that Sent this email: {user_cred} \n"
               f"Bellow is The Attached Invoice File")

    invoice_file_location = os.path.join(settings.MEDIA_ROOT, f"{invoice_document.invoice_file_location}")

    content_type = mimetypes.guess_type(invoice_document.invoice_file_location.name)[0]  # Get the Content MimeType

    if os.path.exists(invoice_file_location):
        with open(invoice_file_location, 'rb') as send_file:
            actual_file = send_file.read()

        email = EmailMessage(subject=subject,
                             body=message,
                             from_email=from_email,
                             to=invoice_team_email)

        email.attach(filename=invoice_document.invoice_filename, content=actual_file, mimetype=content_type)
        email.send(fail_silently=True)
        return True
    else:
        print(f"Invoice does not exist at {invoice_file_location}")
        return False


@shared_task(bind=True)
def remind_invoice_creation_and_send(self):
    all_invoice_parent = InvoiceModel.objects.all()
    timezone = pytz.timezone(settings.TIME_ZONE)
    current_datetime = timezone.localize(datetime.now())

    for invoice_parent in all_invoice_parent:
        time_distance = invoice_parent.current_due_date - current_datetime

        invoice_stage = invoice_parent.current_invoice_stage
        print(invoice_stage)
        print(invoice_parent)
        try:
            particular_invoice_doc = InvoiceModelDetail.objects.get(invoice_id=invoice_parent,
                                                                    invoice_stage=invoice_stage)
        except ObjectDoesNotExist:
            print('Does not exist, you made a data error')
        else:
            project_title = invoice_parent.contract_id.contract_title
            client_name = invoice_parent.contract_id.requisition_by
            invoice_stage = particular_invoice_doc.invoice_stage
            due_date = particular_invoice_doc.due_date
            commercial_email = invoice_parent.contract_id.commercial_personnel.commercial_staff_id.email
            site_url = f"{settings.SITE_URL}/invoice/invoice-detail/{particular_invoice_doc.pk}"

            if time_distance.days < 2 and particular_invoice_doc.invoice_status == 'PENDING':
                print('Less than 2 days')
                subject = 'An Invoice is Pending to be created'
                message = (f'An Invoice for is pending and needs to be created. Project Information is as followed \n'
                           f'Project Info: {project_title} \n'
                           f"Client Name: {client_name} \n"
                           f"Invoice Stage: {invoice_stage} \n"
                           f"Due Date: {due_date} \n"
                           f"Accessible: {site_url} \n"
                           f"Needs to be created, and stored in Less than 2 days")

                send_mail(subject=subject,
                          message=message,
                          from_email=settings.EMAIL_HOST_USER,
                          recipient_list=[commercial_email],
                          fail_silently=True)
                print('Email Invoice Creation Notification Sent Less than 2 Days')

            elif time_distance.days < 7 and particular_invoice_doc.invoice_status == 'PENDING':
                print('Less than 1 Week')
                subject = 'An Invoice is Pending to be created'
                message = (f'An Invoice for is pending and needs to be created. Project Information is as followed \n'
                           f'Project Info: {project_title} \n'
                           f"Client Name: {client_name} \n"
                           f"Invoice Stage: {invoice_stage} \n"
                           f"Due Date: {due_date}\n"
                           f"Accessible: {site_url} \n"
                           f"Needs to be created, and stored in Less than 1 Week")

                send_mail(subject=subject,
                          message=message,
                          from_email=settings.EMAIL_HOST_USER,
                          recipient_list=[commercial_email],
                          fail_silently=True)
                print('Email Invoice Creation Notification Sent Less than 1 Week')

            elif time_distance.days < 14 and particular_invoice_doc.invoice_status == 'PENDING':
                print('Less than 2 weeks')
                subject = 'An Invoice is Pending to be created'
                message = (f'An Invoice for is pending and needs to be created. Project Information is as followed \n'
                           f'Project Info: {project_title} \n'
                           f"Client Name: {client_name} \n"
                           f"Invoice Stage: {invoice_stage} \n"
                           f"Due Date: {due_date} \n"
                           f"Accessible: {site_url} \n"
                           f"Needs to be created, and stored in Less than 2 Weeks")

                send_mail(subject=subject,
                          message=message,
                          from_email=settings.EMAIL_HOST_USER,
                          recipient_list=[commercial_email],
                          fail_silently=True)
                print('Email Invoice Creation Notification Sent Less than 2 Weeks')

            elif time_distance.days < 30 and particular_invoice_doc.invoice_status == 'PENDING':
                print('Less than 1 Month')
                subject = 'An Invoice is Pending to be created'
                message = (f'An Invoice for is pending and needs to be created. Project Information is as followed \n'
                           f'Project Info: {project_title} \n'
                           f"Client Name: {client_name} \n"
                           f"Invoice Stage: {invoice_stage} \n"
                           f"Due Date: {due_date} \n"
                           f"Accessible: {site_url} \n"
                           f"Needs to be created, and stored in Less than 1 Month")

                send_mail(subject=subject,
                          message=message,
                          from_email=settings.EMAIL_HOST_USER,
                          recipient_list=[commercial_email],
                          fail_silently=True)
                print('Email Invoice Creation Notification Sent Less than 1 Month')
            else:
                print('Still Plenty of Time')


@shared_task(bind=True)
def check_invoice_missing(self):
    all_invoice_parent = InvoiceModel.objects.all()

    timezone = pytz.timezone(settings.TIME_ZONE)
    current_datetime = timezone.localize(datetime.now())

    for invoice_parent in all_invoice_parent:
        if invoice_parent.current_due_date < current_datetime:
            current_stage = invoice_parent.current_invoice_stage
            try:
                particular_invoice_doc = InvoiceModelDetail.objects.get(invoice_id=invoice_parent,
                                                                        invoice_stage=current_stage)
            except ObjectDoesNotExist:
                print('object does not exists')
            else:
                site_url = f"{settings.SITE_URL}/invoice/invoice-detail/{particular_invoice_doc.pk}"

                # check if it is pending, update the status as missing, then send email notification
                if particular_invoice_doc.invoice_status == 'PENDING' or particular_invoice_doc.invoice_status == 'MISSING':
                    print('invoice not yet stored')
                    particular_invoice_doc.invoice_status = 'MISSING'
                    particular_invoice_doc.save(not_update_file=True)

                    subject = 'An Invoice is Missing and Needs to be created'
                    message = (f'An Invoice for is missing and needs to be created. Project Information is as followed \n'
                               f'Project Info: {invoice_parent.contract_id.contract_title} \n'
                               f"Client Name: {invoice_parent.contract_id.requisition_by} \n"
                               f"Invoice Stage: {particular_invoice_doc.invoice_stage} \n"
                               f"Accessible: {site_url} \n"
                               f"Due Date: {particular_invoice_doc.due_date}")

                    send_mail(subject=subject,
                              message=message,
                              from_email=settings.EMAIL_HOST_USER,
                              recipient_list=[invoice_parent.contract_id.commercial_personnel.commercial_staff_id.email],
                              fail_silently=True)
                    print('Email Invoice Missing Notification Sent')
                if particular_invoice_doc.invoice_status == 'STORED':
                    print('invoice is stored but not yet sent')
                    subject = 'An Invoice is Stored but Not Yet Sent, Needs To Be Sent Now'
                    message = (f'An Invoice for is Stored but not yet sent. Project Information is as followed \n'
                               f'Project Info: {invoice_parent.contract_id.contract_title} \n'
                               f"Client Name: {invoice_parent.contract_id.requisition_by} \n"
                               f"Invoice Stage: {particular_invoice_doc.invoice_stage} \n"
                               f"Accessible: {site_url} \n"
                               f"Due Date: {particular_invoice_doc.due_date}")

                    send_mail(subject=subject,
                              message=message,
                              from_email=settings.EMAIL_HOST_USER,
                              recipient_list=[invoice_parent.contract_id.commercial_personnel.commercial_staff_id.email],
                              fail_silently=True)
                    print('Email Invoice Not Yet Sent Notification Sent')
                else:
                    print('not yet time to invoice')
