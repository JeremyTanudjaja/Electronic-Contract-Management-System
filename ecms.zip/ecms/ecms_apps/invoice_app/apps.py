from django.apps import AppConfig


class InvoiceAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ecms_apps.invoice_app'
