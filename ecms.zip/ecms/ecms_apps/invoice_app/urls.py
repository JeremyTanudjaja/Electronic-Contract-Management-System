from django.urls import path
from . import views

app_name = 'invoice'

urlpatterns = [
    path('', views.InvoiceListView.as_view(), name='invoice_list'),
    path('invoice-detail/<pk>', views.InvoiceDetailView.as_view(), name='invoice_detail'),

    # additional function
    path('download-invoice/', views.download_invoice, name='download_invoice'),
    path('send-invoice/', views.send_invoice, name='send_invoice'),
    path('get_invoice_template', views.download_invoice_template, name='download_invoice_template'),
    path('generate-invoice-pdf/<pk>', views.generate_invoice_pdf, name='generate_invoice_page'),
    path('show-generated-invoice/<pk>', views.show_generated_invoice, name='show_generated_invoice'),

    # htmx
    path('upload-file/', views.upload_document, name='upload_file'),
    path('generate-invoice/', views.generate_invoice, name='generate_invoice'),
    path('generate-invoice-htmx/', views.generate_invoice_pdf_htmx, name='generate_invoice_htmx')
]
