import os

from django.core.exceptions import ObjectDoesNotExist
from django.core.files.base import ContentFile
from django.db.models import QuerySet
from django.http import HttpResponse, Http404
from django.shortcuts import render, get_object_or_404
from django.utils.crypto import get_random_string
from django.views.generic import TemplateView, ListView, CreateView, DetailView, UpdateView, FormView
from django_htmx.http import HttpResponseClientRefresh
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.conf import settings
from django.core.files import File

from .models import InvoiceModel, InvoiceModelDetail
from .forms import UpdateInvoiceModelDetailForm, GenerateInvoicePDFForm
from ..customer_app.models import CustomerInformation
from ..project_app.models import ContractModel
from django.conf import settings
from datetime import datetime
from .tasks import send_mail_to_invoice

import docx
from fpdf import FPDF
from dateutil.relativedelta import relativedelta


# from docx2pdf import convert


# Create your views here.
class InvoiceListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = InvoiceModel
    template_name = 'invoice_page/invoice_list.html'
    paginate_by = 8
    permission_required = ['invoice_app.view_invoicemodel']

    def get_search_query(self, query_set: QuerySet):
        # check if the method is GET
        if self.request.method == 'GET':
            # check if it is the search form that creates the request via
            # the search-form name value that we insert into the submit button
            if 'search_form_submit' in self.request.GET:
                # if there is a contract_title value
                # print(self.request.GET)
                if self.request.GET.get('project_name'):
                    query_set = query_set.filter(
                        contract_id__contract_title__icontains=self.request.GET.get('project_name'))
                if self.request.GET.get('client_name'):
                    query_set = query_set.filter(
                        contract_id__requisition_by__company_name__icontains=self.request.GET.get('client_name'))
                if self.request.GET.get('invoice_stage'):
                    query_set = query_set.filter(current_invoice_stage=self.request.GET.get('invoice_stage'))
        # print(query_set)
        return query_set

    def get_queryset(self):
        query_set = super().get_queryset()
        query_set = self.get_search_query(query_set)
        return query_set


class InvoiceDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = InvoiceModel
    template_name = 'invoice_page/invoice_detail.html'
    context_object_name = 'invoice_detail'
    permission_required = ['invoice_app.view_invoicemodel', 'invoice_app.view_invoicemodeldetail',
                           'invoice_app.change_invoicemodeldetail']

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        invoice_progression = context['invoice_detail'].invoice_detail.all()
        context['invoice_progression'] = invoice_progression
        return context


@login_required
def upload_document(request):
    if request.htmx:
        if request.FILES.get('file_upload'):
            # print(request.POST)
            # print(request.FILES)
            # print(datetime.now())
            invoice_object = InvoiceModelDetail.objects.get(pk=request.POST.get('invoice_pk'))
            file_data = {'invoice_file_location': request.FILES.get('file_upload')}
            update_status_data = {'invoice_status': 'STORED'}

            form = UpdateInvoiceModelDetailForm(data=update_status_data,
                                                files=file_data,
                                                instance=invoice_object)
            form.save()
            # print(datetime.now())
            updated_invoice_object = InvoiceModelDetail.objects.get(pk=request.POST.get('invoice_pk'))
            invoice_detail = updated_invoice_object.invoice_id

            return render(request, 'invoice_page/invoice_HTMX/invoice_submit_htmx.html',
                          context={'invoice_object': updated_invoice_object,
                                   'invoice_detail': invoice_detail})


@login_required
def download_invoice_template(request):
    if request.POST:
        file = request.POST.get('filepath')
        print(file)
        file_name = str(file).split('/')[-1]
        file_path = os.path.join(settings.STATICFILES_DIRS[0], file)
        print(file_path)
        if os.path.exists(file_path):
            print('exist')
            with open(file_path, 'rb') as f:
                # insert the data inside a variable and open it
                data = f.read()
            response = HttpResponse(data, content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{file_name}"'
            return response
        raise Http404


@login_required
def download_invoice(request):
    if request.POST:

        invoice_object = InvoiceModelDetail.objects.get(pk=request.POST.get('invoice_pk'))
        file_path = os.path.join(settings.MEDIA_ROOT, f"{invoice_object.invoice_file_location}")

        if os.path.exists(file_path):
            print('file exists')

            # we then need to open the document, we set it as read-binary to handle
            # text and images if there are any
            with open(file_path, 'rb') as f:
                # insert the data inside a variable and open it
                data = f.read()

            response = HttpResponse(data, content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{invoice_object.invoice_filename}"'

            return response

        raise Http404


@login_required
def send_invoice(request):
    if request.htmx:
        invoice_detail_pk = request.POST.get('invoice_pk')
        this_invoice_document = InvoiceModelDetail.objects.get(pk=invoice_detail_pk)
        this_invoice = this_invoice_document.invoice_id
        user_that_sent_the_invoice = f"{request.user.first_name} {request.user.last_name} [{request.user.role}]"

        # send email
        if this_invoice_document.invoice_status == 'STORED' or this_invoice_document.invoice_status == 'SENT':
            print('Invoice status means invoice exist, Invoice can be sent')
            send_mail_to_invoice.delay(invoice_document_pk=invoice_detail_pk, user_cred=user_that_sent_the_invoice)
        else:
            print('Invoice Cannot be sent')

        # update this_invoice_document status, since we can't check if the email action is done (email is sent asyncly)
        # the best thing we can do is to check whether file exist or not. If the file exist, email should be sent
        # successfully
        invoice_file_location = os.path.join(settings.MEDIA_ROOT, f"{this_invoice_document.invoice_file_location}")
        if os.path.exists(invoice_file_location):

            # update this_invoice current invoicing stage and due date by filtering the next

            # update the particular invoice document status from Stored to Sent
            this_invoice_document.invoice_status = 'SENT'
            this_invoice_document.save(not_update_file=True)

            # check if the current invoice stage is at the last invoice stage
            # if it is, then set the invoicing done attribute to true
            if this_invoice.current_invoice_stage == this_invoice.max_invoice_stage:
                this_invoice.invoicing_done = True
                this_invoice.save()

            # checks if the current invoicing stage is lower than our sent invoice stage
            # if it is lower, we can update it
            if this_invoice.current_invoice_stage == this_invoice_document.invoice_stage:
                next_stage = this_invoice_document.invoice_stage + 1
                try:
                    next_invoice_document = InvoiceModelDetail.objects.get(invoice_id=this_invoice,
                                                                           invoice_stage=next_stage)
                except ObjectDoesNotExist:
                    next_invoice_document = False
                if next_invoice_document:
                    # update the invoice parent with the next invoice document to be sent
                    this_invoice.current_invoice_stage = next_invoice_document.invoice_stage
                    this_invoice.current_due_date = next_invoice_document.due_date
                    this_invoice.save()
                else:
                    print('No More Invoice To be Sent')
            else:
                print('Missmatch contract stage')
    return HttpResponseClientRefresh()


def generate_document(invoice_object: InvoiceModelDetail) -> docx.Document:
    invoice_document = docx.Document()

    project_title = invoice_object.invoice_id.contract_id.contract_title
    project_data = invoice_object.invoice_id.contract_id
    client_data = invoice_object.invoice_id.contract_id.requisition_by

    invoice_document.add_heading("PT XYZ Invoicing Statement", 0)

    invoice_document.add_paragraph(project_title)

    # Client Name       Invoice Creation Date
    # Client Address    Billing Period
    # Emirate(Province) Payment Term
    # Client Contact    Due Date (+1 Month)
    # Currency (AED)

    left_data = [f"Name: {client_data.company_name}",
                 f"Address: {client_data.company_address}",
                 f"Emirate: {client_data.company_region}",
                 (f"Attention: {project_data.client_contact.contact_first_name} "
                  f"{project_data.client_contact.contact_last_name}"),
                 f"Currency: AED"]
    right_data = [f"Invoice Date: {invoice_object.due_date.strftime('%d-%B-%Y')}",
                  f"Billing Period: {invoice_object.due_date.strftime('%B')}",
                  f"Payment Terms: FULL (30 Days)",
                  f"Due Date: {(invoice_object.due_date + relativedelta(months=1)).strftime('%d-%B-%Y')}"]
    invoice_detail_table = invoice_document.add_table(rows=5, cols=2)
    for i in range(5):
        try:
            invoice_detail_table.rows[i].cells[0].text = left_data[i]
            invoice_detail_table.rows[i].cells[1].text = right_data[i]
        except IndexError:
            print("pass value error")

    # Invoice Detail
    # No Description Qty Unit_Price Amount_Before_text Tax_Rate Tax_Amount Total_Amount
    invoice_payment_table = invoice_document.add_table(rows=2, cols=8, style="TableGrid")
    invoice_data = [['No', 'Description', 'Qty', 'Unit Price', 'Amount Before Tax', 'Tax Rate', 'Tax Amount',
                     'Total Amount'],
                    ['1',
                     f'{project_data.contract_title} - Installment {invoice_object.invoice_stage}',
                     '1',
                     f'{invoice_object.payment_value:,d}',
                     f'{invoice_object.payment_value:,d}',
                     '11%',
                     '{:,.2f}'.format((invoice_object.payment_value * 11) / 100),
                     f'{invoice_object.payment_after_tax:,d}']]
    for i in range(2):
        for j in range(8):
            invoice_payment_table.rows[i].cells[j].text = invoice_data[i][j]

    return invoice_document


@login_required
def generate_invoice(request):
    if request.htmx:
        invoice_object = InvoiceModelDetail.objects.get(pk=request.POST.get('invoice_pk'))
        invoice_detail = invoice_object.invoice_id

        invoice_random_name = get_random_string(4, 'ABCDEFGHIJKLMNOPQRSTUWVXYZ')

        save_path = (f'{invoice_object.invoice_id.contract_id.requisition_by}/'
                     f'{invoice_object.invoice_id.contract_id.contract_type}/'
                     f'{invoice_object.invoice_id.contract_id.contract_title}/'
                     f'Invoice/'
                     f'{invoice_object.invoice_stage}/')

        dir_docs = os.path.join(settings.MEDIA_ROOT, save_path)
        save_path_docx = os.path.join(dir_docs, f"Invoice-{invoice_object.invoice_stage}.docx")

        # Saving pdf does not work, need to convert word to pdf but this leads to problems
        # regarding permission in the computer. I Do not know how to fix this
        # save_path_pdf = os.path.join(dir_docs, f"Invoice-{invoice_object.invoice_stage}-{invoice_random_name}.pdf")

        # Create the invoice document
        project_title = invoice_object.invoice_id.contract_id.contract_title

        invoice_document = generate_document(invoice_object=invoice_object)

        # Create the docx and pdf
        try:
            print(f'Docx Path: {save_path_docx}')
            invoice_document.save(save_path_docx)
        except FileNotFoundError:
            print('fine not found trigger')
            os.makedirs(dir_docs)
        finally:
            print('finally statement run')
            invoice_document.save(save_path_docx)
            # There used to be a convert to pdf line of code using docx2pdf or word2pdf (i forgot)
            # it does not work so i deleted it.

        # save to database
        update_status_data = {'invoice_status': 'STORED'}

        # Open and read the temporary file and create a Django ContentFile object

        with open(save_path_docx, "rb") as temp_file:
            file_content = temp_file.read()

        file_data = ContentFile(file_content, name=f"Invoice-{invoice_object.invoice_stage}-{invoice_random_name}.docx")
        files_data = {'invoice_file_location': file_data}
        form = UpdateInvoiceModelDetailForm(data=update_status_data,
                                            files=files_data,
                                            instance=invoice_object)
        form.save()

        # remove the previously generated file, because we save it using django, there's a double
        try:
            os.remove(save_path_docx)
        except FileNotFoundError:
            print('file not found, generated file deletion cannot be done')

        return render(request, 'invoice_page/invoice_HTMX/invoice_submit_htmx.html',
                      context={'invoice_object': invoice_object, 'invoice_detail': invoice_detail})


@login_required
def generate_invoice_pdf(request, pk):
    # get the default value
    invoice_doc_pk = pk
    invoice_document = InvoiceModelDetail.objects.get(pk=invoice_doc_pk)
    invoice_parent = invoice_document.invoice_id
    project_title = invoice_parent.contract_id
    client_data = project_title.requisition_by
    invoice_random_name = get_random_string(4, 'ABCDEFGHIJKLMNOPQRSTUWVXYZ')

    # Generate Form and input the initial value
    form = GenerateInvoicePDFForm()
    form.fields['invoice_title'].initial = f'PT XYZ Invoicing Statement - {client_data.company_name}'
    form.fields[
        'invoice_description'].initial = f'{project_title.contract_title}-Installment {invoice_document.invoice_stage}'
    form.fields['invoice_tax_percentage'].initial = 11
    form.fields['invoice_filename'].initial = f"Invoice-{invoice_random_name}-{invoice_document.invoice_stage}"

    context_data = {'invoice_doc_pk': invoice_doc_pk,
                    'form': form}
    return render(request, 'invoice_page/invoice_generate.html', context=context_data)


def create_the_actual_invoice_pdf(data, invoice_doc: InvoiceModelDetail) -> FPDF:
    """ Returns The PDF"""
    # Decide Payment Term Date
    if data['invoice_billing_period'] == 'FULL TERM (30 DAYS)':
        print('full payment term')
        paid_date = (invoice_doc.due_date + relativedelta(months=1)).strftime('%d-%B-%Y')
    else:
        print('not full payment term')
        paid_date = (invoice_doc.due_date + relativedelta(days=15)).strftime('%d-%B-%Y')

    # create fpdf object, Layout: P or L, unit: mm or cm or inc, format: A4 or A5 or Letter or  A3 or Legal
    pdf_doc = FPDF('P', 'mm', 'A4')

    # Add Page
    pdf_doc.add_page()

    # specify Font
    # fonts ('times', 'courier', 'helvetica', 'symbol')
    # 'B' (bold), 'U' (Underline), 'I' (Italic), '' (regular)
    pdf_doc.set_font('helvetica', '', 12)

    # Add Text
    # w = width, h = height
    print('adding the information')
    pdf_doc.cell(0, 16, f"{data['invoice_title']}", ln=True)
    pdf_doc.cell(0, 16, f"{invoice_doc.invoice_id.contract_id.contract_title}", ln=True)
    pdf_doc.cell(0, 16, '', ln=True)

    pdf_doc.cell(120, 16, f"Name: {invoice_doc.invoice_id.contract_id.requisition_by.company_name}")
    pdf_doc.cell(40, 16, f"Invoice Date: {invoice_doc.due_date.strftime('%d-%B-%Y')}", ln=True)

    pdf_doc.cell(120, 16, f"Address: {invoice_doc.invoice_id.contract_id.requisition_by.company_name}")
    pdf_doc.cell(40, 16, f"Billing Period: {invoice_doc.due_date.strftime('%B')}", ln=True)

    pdf_doc.cell(120, 16, f"Emirate: {invoice_doc.invoice_id.contract_id.requisition_by.company_region}")
    pdf_doc.cell(40, 16, f"Payment Term: {data['invoice_billing_period']}", ln=True)

    pdf_doc.cell(120, 16,
                 f"Attention: {invoice_doc.invoice_id.contract_id.client_contact.contact_first_name} {invoice_doc.invoice_id.contract_id.client_contact.contact_last_name}")
    pdf_doc.cell(40, 16, f"Due Date: {paid_date}", ln=True)

    pdf_doc.cell(40, 16, f"Currency: Arab Emirate Dirham (AED)", ln=True)

    tax_amount = int((invoice_doc.payment_value * int(data['invoice_tax_percentage'])) / 100)
    total_amount = int(invoice_doc.payment_value + tax_amount)

    print('adding the table data')
    TABLE_DATA = (
        ("No", "Description", 'Qty', 'Unit Price', 'Amount Before Tax', 'Tax Rate', 'Tax Amount', 'Total Amount'),
        (
        "1", f"{data['invoice_description']}", "1", f"{invoice_doc.payment_value:,d}", f"{invoice_doc.payment_value:,d}"
        , f"{data['invoice_tax_percentage']}%", f"{tax_amount:,d}", f"{total_amount:,d}")
    )

    with pdf_doc.table() as table:
        for data_row in TABLE_DATA:
            row = table.row()
            for datum in data_row:
                row.cell(datum)

    return pdf_doc


def generate_invoice_pdf_htmx(request):
    if request.htmx:
        invoice_object = InvoiceModelDetail.objects.get(pk=request.POST.get('invoice-doc-pk'))

        pdf_file_name = request.POST.get('invoice_filename')

        invoice_random_name = get_random_string(4, 'ABCDEFGHIJKLMNOPQRSTUWVXYZ')
        pdf_dummy_name = f"Invoice-{invoice_random_name}-{invoice_object.invoice_stage}"

        print('before create pdf doc')
        pdf_doc = create_the_actual_invoice_pdf(data=request.POST, invoice_doc=invoice_object)
        print('after creation of pdf doc')

        save_path = (f'{invoice_object.invoice_id.contract_id.requisition_by}/'
                     f'{invoice_object.invoice_id.contract_id.contract_type}/'
                     f'{invoice_object.invoice_id.contract_id.contract_title}/'
                     f'Invoice/'
                     f'{invoice_object.invoice_stage}/')

        dir_pdf = os.path.join(settings.MEDIA_ROOT, save_path)
        save_path_pdf = os.path.join(dir_pdf, f"{pdf_dummy_name}.pdf")

        # Create the pdf
        try:
            print(f'PDF Path: {save_path_pdf}')
            pdf_doc.output(save_path_pdf)
        except FileNotFoundError:
            print('fine not found trigger')
            os.makedirs(dir_pdf)
        finally:
            print('finally statement run')
            pdf_doc.output(save_path_pdf)

        # save to database
        update_status_data = {'invoice_status': 'STORED'}

        # Open and read the temporary file and create a Django ContentFile object

        print('before opening file')
        with open(save_path_pdf, "rb") as temp_file:
            file_content = temp_file.read()

        file_data = ContentFile(file_content,
                                name=f"{pdf_file_name}.pdf")
        files_data = {'invoice_file_location': file_data}
        form = UpdateInvoiceModelDetailForm(data=update_status_data,
                                            files=files_data,
                                            instance=invoice_object)
        form.save()

        # remove the previously generated file, because we save it using django, there's a double
        print('removing the dummy file')
        try:
            os.remove(save_path_pdf)
        except FileNotFoundError:
            print('file not found, generated file deletion cannot be done')

        actual_path_pdf = os.path.join(dir_pdf, f"{pdf_file_name}.pdf")
        context_data = {
            'pdf_file': f'http://127.0.0.1:8000/invoice/show-generated-invoice/{request.POST.get("invoice-doc-pk")}',
            'pk': request.POST.get('invoice-doc-pk'),
            'parent_id': invoice_object.invoice_id.pk}

        return render(request, 'invoice_page/invoice_HTMX/invoice_generate_htmx.html', context=context_data)


def show_generated_invoice(request, pk):
    invoice_object = InvoiceModelDetail.objects.get(pk=pk)
    file_path = os.path.join(settings.MEDIA_ROOT, f"{invoice_object.invoice_file_location}")

    if os.path.exists(file_path):
        print('file exists')

        # we then need to open the document, we set it as read-binary to handle
        # text and images if there are any
        with open(file_path, 'rb') as f:
            # insert the data inside a variable and open it
            data = f.read()

        response = HttpResponse(data, content_type='application/pdf')
        response['Content-Disposition'] = f'inline; filename="{invoice_object.invoice_filename}.pdf"'
        response['X-Frame-Options'] = 'SAMEORIGIN'

        return response
    return HttpResponse('File not found', status=404)

