from django.contrib import admin
from .models import InvoiceModel, InvoiceModelDetail


# Admin
class InvoiceDetailAdmin(admin.ModelAdmin):
    list_filter = ['invoice_status']


# Register your models here.
admin.site.register(InvoiceModel)
admin.site.register(InvoiceModelDetail, InvoiceDetailAdmin)
