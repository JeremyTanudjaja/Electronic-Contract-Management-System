from django.db import models


# Create your models here.
class InvoiceModel(models.Model):
    contract_id = models.OneToOneField('project_app.ContractModel', on_delete=models.RESTRICT,
                                       related_name='invoice_contract')
    current_invoice_stage = models.IntegerField(default=1)  # update after invoice file sent to invoice team
    max_invoice_stage = models.IntegerField(default=1)
    current_due_date = models.DateTimeField(null=True)  # update after invoice file sent to invoice team
    invoicing_done = models.BooleanField(null=True)  # After the last invoice is sent on
    # the last invoice stage, set this to true to indicate that the all invoice is done

    def __str__(self):
        return f"{self.contract_id}"


class InvoiceModelDetail(models.Model):
    class InvoiceStatus(models.TextChoices):
        PENDING = 'PENDING', 'Pending'
        MISSING = 'MISSING', 'Missing'
        STORED = 'STORED', 'Stored'
        SENT = 'SENT', 'Sent'

    def upload_directory(instance, filename):
        return (f"{instance.invoice_id.contract_id.requisition_by}/{instance.invoice_id.contract_id.contract_type}/"
                f"{instance.invoice_id.contract_id.contract_title}"
                f"/Invoice/"
                f"{instance.invoice_stage}/{filename}")

    invoice_id = models.ForeignKey(InvoiceModel, on_delete=models.RESTRICT, related_name='invoice_detail')
    invoice_stage = models.IntegerField()
    payment_percentage = models.FloatField(null=True)
    payment_value = models.IntegerField(null=True)
    payment_after_tax = models.IntegerField(null=True)
    invoice_file_location = models.FileField(null=True, max_length=255, upload_to=upload_directory)
    invoice_filename = models.CharField(null=True, max_length=255)
    invoice_status = models.CharField(default=InvoiceStatus.PENDING, choices=InvoiceStatus.choices, max_length=255)
    # optional
    # payment_terms = models.CharField()
    due_date = models.DateTimeField(null=True)

    def __str__(self):
        return f"{self.invoice_id}-Invoice-{self.invoice_stage}"

    def save(self, *args, **kwargs):
        # the self.attributes is populated with the parsed value when we want to create
        # or delete. Basically this will check if there is a file currently. If there is, then
        # this is going to be an update action i.e. we delete then save the file
        self.invoice_filename = str(self.invoice_file_location.name).split('/')[-1]
        try:
            this = InvoiceModelDetail.objects.get(id=self.id)
            if kwargs.get('not_update_file'):
                print(kwargs.get('not_update_file'))
                print("don't delete file")
                kwargs.pop('not_update_file')
            else:
                print("there's a file")
                if this.invoice_file_location:
                    this.invoice_file_location.delete()
        except:
            pass
        return super().save(*args, **kwargs)
