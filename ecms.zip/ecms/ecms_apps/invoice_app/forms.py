from django import forms
from .models import InvoiceModel, InvoiceModelDetail


class UpdateInvoiceModelDetailForm(forms.ModelForm):
    class Meta:
        model = InvoiceModelDetail
        fields = ['invoice_file_location', 'invoice_status']


class GenerateInvoicePDFForm(forms.Form):

    billing_period_choices = (('FULL TERM (30 DAYS)', 'Full Term (30 Days)'),
                              ('HALF TERM (15 DAYS)', 'Half Term (15 Days)'))

    invoice_title = forms.CharField(max_length=255)
    invoice_description = forms.CharField(max_length=255)
    invoice_filename = forms.CharField(max_length=255)
    invoice_billing_period = forms.ChoiceField(choices=billing_period_choices)
    invoice_tax_percentage = forms.IntegerField()



