console.log('Hello World')
var uploadForm = document.getElementsByClassName('file-submit-form')
var uploadInput = document.getElementsByName('file_upload')
var pkInput = document.getElementsByClassName('invoice_pk')

var progressBox = document.getElementsByClassName('progress-bar')
var csrf = document.getElementsByName('csrfmiddlewaretoken')
var target = document.getElementsByClassName('invoice-container')
console.log(pkInput)
console.log(target)
//console.log(uploadForm)
//console.log(uploadInput)
//console.log(progressBox)
//console.log(csrf)
for(var i = 0; i < uploadForm.length; i++){
    uploadInput[i].addEventListener('change', ()=>{
        progressBox[i].classList.remove('not-visible')

        var img_data = uploadInput[i].files[0] // the image data
        var pk_data = pkInput[i]

        var form_data = new FormData()
        form_data.append('csrfmiddlewaretoken', csrf[i][0].value) //get the csrf token
        form_data.append('file_upload', img_data)
        form_data.append('invoice_pk', )

        $.ajax({
            type: 'POST',
            url: uploadForm[i].action,
            enctype: 'multipart/form-data',
            data: form_data,
            beforeSend: function(){},
            xhr: function(){
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', e=>{
                    if(e.lengthComputable){
                        var percent = e.loaded / e.total * 100
                        console.log(percent)
                        progressBox[i].innerHTML = `
                        <div class="progress" style="width: ${percent}%; height:100%; background-color:blue">
                        </div>
                        `
                    }
                })
                return xhr
            },
            success: function(response){
                target[i].innerHTML = response
            },
            error: function(error){
                console.log(error)
            },
            cache: false,
            contentType: false,
            processData: false,
        })
    })
}