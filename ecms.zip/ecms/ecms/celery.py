# addition, this is different from the celery docs
from __future__ import absolute_import, unicode_literals

# base celery imports
import os
from celery import Celery
from celery.schedules import crontab
from django.conf import settings

# Set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ecms.settings')

app = Celery('ecms')

# by default the timezone is set to UTC, but we have set it into Asia/Jakarta so we
# need to make this false
app.conf.enable_utc = False

# update the timezone again
app.conf.update(timezone='Asia/Jakarta')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object('django.conf:settings', namespace='CELERY')

# Celery beat Settings
# for celery beat tasks
app.conf.beat_schedule = {
    'check-project-last-update': {
        'task': 'ecms_apps.project_app.tasks.check_last_update_every_week',
        'schedule': crontab(minute='59', hour='23', day_of_week='1'),
        # 'schedule': crontab(minute='13', hour='12'),
        # 'args': (2, ) We can parse argument to our task
    },
    'remind-invoice-creation-and-send': {
        'task': 'ecms_apps.invoice_app.tasks.remind_invoice_creation_and_send',
        'schedule': crontab(minute='59', hour='23', day_of_week='6'),
        # 'schedule': crontab(minute='36', hour='15'),
        # 'args': (2, ) We can parse argument to our task
    },
    'check-invoice-missing': {
        'task': 'ecms_apps.invoice_app.tasks.check_invoice_missing',
        'schedule': crontab(minute='59', hour='23', day_of_week='5'),
        # 'schedule': crontab(minute='41', hour='15'),
    }
}


# Load task modules from all registered Django apps.
app.autodiscover_tasks()

@app.task(bind=True, ignore_result=True)
def debug_task(self):
    print(f'Request: {self.request!r}')

# to run celery
# open a new terminal (we need 1 terminal for django, 1 for celery, and another for celery-beat)
# type cd ecms in all of the terminal
# in the celery terminal, type: celery -A ecms.celery worker --pool=solo -l info
# that will run our celery server
# in the celery-beat terminal, type: celery -A ecms beat -l INFO

# NOTE: because we are using django_celery_results, we will get all the celery log info
# to our django database. So before we run anything, we need to make sure that the log info
# table is already in the database. We need to migrate (normal migration using django) to
# create the table if it does not exist
